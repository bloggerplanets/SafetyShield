import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enhanced User schema with more fields
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  role: text("role").notNull().default("user"), // admin, user, manager
  department: text("department"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  lastLogin: timestamp("last_login"),
  avatar: text("avatar"),
  resetToken: text("reset_token"),
  resetTokenExpiry: timestamp("reset_token_expiry"),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  lastLogin: true,
  resetToken: true,
  resetTokenExpiry: true,
  isActive: true,
}).extend({
  password: z.string().min(8, "Password must be at least 8 characters"),
  email: z.string().email("Please enter a valid email"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Incident schema
export const incidents = pgTable("incidents", {
  id: serial("id").primaryKey(),
  incidentId: text("incident_id").notNull(), // Format: INC-YYYY-XXX
  type: text("type").notNull(), // Accident, Near Miss, Hazard
  description: text("description").notNull(),
  location: text("location").notNull(),
  reportedBy: text("reported_by").notNull(),
  reportedDate: timestamp("reported_date").notNull(),
  status: text("status").notNull(), // Open, In Progress, Closed
  severity: text("severity").notNull(), // Low, Medium, High
  assignedTo: text("assigned_to"),
  dueDate: timestamp("due_date"),
  closedDate: timestamp("closed_date"),
  actions: text("actions"),
});

export const insertIncidentSchema = createInsertSchema(incidents).omit({
  id: true,
});

export type InsertIncident = z.infer<typeof insertIncidentSchema>;
export type Incident = typeof incidents.$inferSelect;

// Document schema
export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category").notNull(), // Policy, Procedure, Training, Report
  fileName: text("file_name").notNull(),
  uploadedBy: text("uploaded_by").notNull(),
  uploadDate: timestamp("upload_date").notNull(),
  expiryDate: timestamp("expiry_date"),
  status: text("status").notNull(), // Active, Archived, Expired
});

export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
});

export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documents.$inferSelect;

// Compliance item schema
export const complianceItems = pgTable("compliance_items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  standard: text("standard").notNull(), // OSHA, ISO 45001, Internal
  category: text("category").notNull(), // e.g., Hazard Communication, Risk Assessment
  description: text("description"),
  dueDate: timestamp("due_date"),
  completionDate: timestamp("completion_date"),
  status: text("status").notNull(), // Compliant, Non-Compliant, In Progress
  percentComplete: integer("percent_complete").notNull(),
  assignedTo: text("assigned_to"),
  evidence: text("evidence"),
});

export const insertComplianceItemSchema = createInsertSchema(complianceItems).omit({
  id: true,
});

export type InsertComplianceItem = z.infer<typeof insertComplianceItemSchema>;
export type ComplianceItem = typeof complianceItems.$inferSelect;

// Audit schema
export const audits = pgTable("audits", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  auditType: text("audit_type").notNull(), // Internal, External
  scheduledDate: timestamp("scheduled_date").notNull(),
  completedDate: timestamp("completed_date"),
  status: text("status").notNull(), // Scheduled, In Progress, Completed
  auditor: text("auditor").notNull(),
  location: text("location").notNull(),
  findings: text("findings"),
});

export const insertAuditSchema = createInsertSchema(audits).omit({
  id: true,
});

export type InsertAudit = z.infer<typeof insertAuditSchema>;
export type Audit = typeof audits.$inferSelect;

// Risk assessment schema
export const riskAssessments = pgTable("risk_assessments", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  location: text("location").notNull(),
  assessedBy: text("assessed_by").notNull(),
  assessmentDate: timestamp("assessment_date").notNull(),
  reviewDate: timestamp("review_date"),
  hazards: jsonb("hazards").notNull(), // Array of hazard details
  controls: jsonb("controls").notNull(), // Array of control measures
  likelihood: integer("likelihood").notNull(), // 1-5 scale
  severity: integer("severity").notNull(), // 1-5 scale
  riskRating: integer("risk_rating").notNull(), // Calculated: likelihood * severity
  status: text("status").notNull(), // Draft, Active, Archived
});

export const insertRiskAssessmentSchema = createInsertSchema(riskAssessments).omit({
  id: true,
});

export type InsertRiskAssessment = z.infer<typeof insertRiskAssessmentSchema>;
export type RiskAssessment = typeof riskAssessments.$inferSelect;

// Task schema
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  dueDate: timestamp("due_date").notNull(),
  assignedTo: text("assigned_to").notNull(),
  status: text("status").notNull(), // Not Started, In Progress, Completed, Overdue
  priority: text("priority").notNull(), // Low, Medium, High
  relatedEntityType: text("related_entity_type"), // Incident, Compliance, Risk, Audit
  relatedEntityId: integer("related_entity_id"),
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
});

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

// Learning Management System (LMS) schema
export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category").notNull(), // Safety, Compliance, Technical, Soft Skills
  duration: integer("duration").notNull(), // in minutes
  instructorId: integer("instructor_id").references(() => users.id),
  status: text("status").notNull(), // Active, Draft, Archived
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at"),
  thumbnail: text("thumbnail"),
  level: text("level").notNull(), // Beginner, Intermediate, Advanced
  required: boolean("required").default(false),
  expiryDays: integer("expiry_days"), // Days after completion when re-training is required
});

export const insertCourseSchema = createInsertSchema(courses).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Course = typeof courses.$inferSelect;

// Course modules
export const courseModules = pgTable("course_modules", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id").notNull().references(() => courses.id),
  title: text("title").notNull(),
  description: text("description"),
  content: text("content").notNull(),
  sortOrder: integer("sort_order").notNull(),
  durationMinutes: integer("duration_minutes"),
  contentType: text("content_type").notNull(), // Video, Text, Quiz, Interactive
  resourceUrl: text("resource_url"),
});

export const insertCourseModuleSchema = createInsertSchema(courseModules).omit({
  id: true,
});

export type InsertCourseModule = z.infer<typeof insertCourseModuleSchema>;
export type CourseModule = typeof courseModules.$inferSelect;

// User course enrollments
export const courseEnrollments = pgTable("course_enrollments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  courseId: integer("course_id").notNull().references(() => courses.id),
  enrolledAt: timestamp("enrolled_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  progress: integer("progress").default(0), // Percentage of completion
  status: text("status").notNull(), // Not Started, In Progress, Completed, Expired
  expiresAt: timestamp("expires_at"), // When the certification expires
  score: integer("score"), // Final test score if applicable
});

export const insertEnrollmentSchema = createInsertSchema(courseEnrollments).omit({
  id: true,
  enrolledAt: true,
});

export type InsertEnrollment = z.infer<typeof insertEnrollmentSchema>;
export type CourseEnrollment = typeof courseEnrollments.$inferSelect;

// Calendar events
export const calendarEvents = pgTable("calendar_events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  allDay: boolean("all_day").default(false),
  location: text("location"),
  organizerId: integer("organizer_id").references(() => users.id),
  eventType: text("event_type").notNull(), // Training, Audit, Meeting, Deadline
  relatedEntityType: text("related_entity_type"), // Course, Audit, Compliance, Task
  relatedEntityId: integer("related_entity_id"),
  reminderMinutes: integer("reminder_minutes"),
  isRecurring: boolean("is_recurring").default(false),
  recurrencePattern: text("recurrence_pattern"), // JSON string with recurrence rules
  color: text("color"), // Color for the calendar event
});

export const insertCalendarEventSchema = createInsertSchema(calendarEvents).omit({
  id: true,
});

export type InsertCalendarEvent = z.infer<typeof insertCalendarEventSchema>;
export type CalendarEvent = typeof calendarEvents.$inferSelect;

// Calendar event attendees
export const eventAttendees = pgTable("event_attendees", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").notNull().references(() => calendarEvents.id),
  userId: integer("user_id").notNull().references(() => users.id),
  status: text("status").notNull(), // Invited, Accepted, Declined, Tentative
});

export const insertEventAttendeeSchema = createInsertSchema(eventAttendees).omit({
  id: true,
});

export type InsertEventAttendee = z.infer<typeof insertEventAttendeeSchema>;
export type EventAttendee = typeof eventAttendees.$inferSelect;
