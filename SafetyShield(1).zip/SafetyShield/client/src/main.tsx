import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add custom CSS variables for our color scheme
const style = document.createElement('style');
style.textContent = `
  :root {
    --background: 0 0% 100%;
    --foreground: 222.2 47.4% 11.2%;
    
    --primary: 203 100% 36%; /* #006CB7 (trust blue) */
    --primary-foreground: 210 40% 98%;
    
    --secondary: 145 65% 42%; /* #27AE60 (safety green) */
    --secondary-foreground: 210 40% 98%;
    
    --accent: 145 65% 42%; /* #27AE60 */
    --accent-foreground: 222.2 47.4% 11.2%;
    
    --destructive: 354 70% 54%; /* #E74C3C (warning red) */
    --destructive-foreground: 210 40% 98%;
    
    --muted: 210 40% 96.1%;
    --muted-foreground: 215.4 16.3% 46.9%;
    
    --card: 0 0% 100%;
    --card-foreground: 222.2 47.4% 11.2%;
    
    --popover: 0 0% 100%;
    --popover-foreground: 222.2 47.4% 11.2%;
    
    --border: 214.3 31.8% 91.4%;
    --input: 214.3 31.8% 91.4%;
    --ring: 203 100% 36%;
    
    --radius: 0.5rem;
    
    --text-color: 215 33% 25%; /* #2C3E50 (dark blue-grey) */
    --neutral-color: 220 13% 97%; /* #F5F7FA (light grey) */

    --chart-1: 203 100% 36%;
    --chart-2: 145 65% 42%;
    --chart-3: 354 70% 54%;
    --chart-4: 43 100% 50%;
    --chart-5: 212 100% 40%;
  }

  .dark {
    --background: 222.2 84% 4.9%;
    --foreground: 210 40% 98%;
    
    --primary: 203 100% 36%;
    --primary-foreground: 210 40% 98%;
    
    --secondary: 145 65% 42%;
    --secondary-foreground: 210 40% 98%;
    
    --accent: 217.2 32.6% 17.5%;
    --accent-foreground: 210 40% 98%;
    
    --destructive: 354 70% 54%;
    --destructive-foreground: 210 40% 98%;
    
    --muted: 217.2 32.6% 17.5%;
    --muted-foreground: 215 20.2% 65.1%;
    
    --card: 222.2 84% 4.9%;
    --card-foreground: 210 40% 98%;
    
    --popover: 222.2 84% 4.9%;
    --popover-foreground: 210 40% 98%;
    
    --border: 217.2 32.6% 17.5%;
    --input: 217.2 32.6% 17.5%;
    --ring: 202.9 83.3% 42.7%;
  }
`;
document.head.appendChild(style);

createRoot(document.getElementById("root")!).render(<App />);
