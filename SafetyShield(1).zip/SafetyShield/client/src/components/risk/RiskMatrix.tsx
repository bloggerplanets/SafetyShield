interface RiskMatrixProps {
  selectedLikelihood?: number;
  selectedSeverity?: number;
}

const RiskMatrix = ({ selectedLikelihood, selectedSeverity }: RiskMatrixProps) => {
  // Define risk levels and their colors
  const riskLevels = {
    low: "bg-green-100 text-green-800 border-green-200",
    medium: "bg-yellow-100 text-yellow-800 border-yellow-200",
    high: "bg-orange-100 text-orange-800 border-orange-200",
    critical: "bg-red-100 text-red-800 border-red-200"
  };
  
  // Matrix data structure [likelihood][severity] = risk level
  const matrix = [
    // This is unused, just to make indexing easier
    ["", "", "", "", "", ""],
    ["", riskLevels.low, riskLevels.low, riskLevels.low, riskLevels.medium, riskLevels.medium],
    ["", riskLevels.low, riskLevels.low, riskLevels.medium, riskLevels.medium, riskLevels.high],
    ["", riskLevels.low, riskLevels.medium, riskLevels.medium, riskLevels.high, riskLevels.high],
    ["", riskLevels.medium, riskLevels.medium, riskLevels.high, riskLevels.high, riskLevels.critical],
    ["", riskLevels.medium, riskLevels.high, riskLevels.high, riskLevels.critical, riskLevels.critical]
  ];
  
  // Get the cell class based on position and selection
  const getCellClass = (likelihood: number, severity: number) => {
    const isSelected = selectedLikelihood === likelihood && selectedSeverity === severity;
    const baseClass = matrix[likelihood][severity];
    
    return `${baseClass} ${isSelected ? 'ring-2 ring-primary' : ''} border`;
  };
  
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200 border">
        <thead>
          <tr>
            <th className="p-2 bg-gray-50 text-xs font-medium text-gray-500 border">
              <div className="text-center">Likelihood ↓ Severity →</div>
            </th>
            <th className="p-2 bg-gray-50 text-xs font-medium text-gray-500 border">1</th>
            <th className="p-2 bg-gray-50 text-xs font-medium text-gray-500 border">2</th>
            <th className="p-2 bg-gray-50 text-xs font-medium text-gray-500 border">3</th>
            <th className="p-2 bg-gray-50 text-xs font-medium text-gray-500 border">4</th>
            <th className="p-2 bg-gray-50 text-xs font-medium text-gray-500 border">5</th>
          </tr>
        </thead>
        <tbody>
          {[1, 2, 3, 4, 5].map(likelihood => (
            <tr key={likelihood}>
              <td className="p-2 bg-gray-50 text-xs font-medium text-gray-500 text-center border">
                {likelihood}
              </td>
              {[1, 2, 3, 4, 5].map(severity => (
                <td 
                  key={severity}
                  className={`p-2 text-center text-xs font-medium ${getCellClass(likelihood, severity)}`}
                >
                  {likelihood * severity}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      
      <div className="grid grid-cols-2 gap-2 mt-3">
        <div className="text-xs p-1 text-center rounded-md border bg-green-100 text-green-800 border-green-200">
          Low (1-4)
        </div>
        <div className="text-xs p-1 text-center rounded-md border bg-yellow-100 text-yellow-800 border-yellow-200">
          Medium (5-9)
        </div>
        <div className="text-xs p-1 text-center rounded-md border bg-orange-100 text-orange-800 border-orange-200">
          High (10-14)
        </div>
        <div className="text-xs p-1 text-center rounded-md border bg-red-100 text-red-800 border-red-200">
          Critical (15-25)
        </div>
      </div>
    </div>
  );
};

export default RiskMatrix;
