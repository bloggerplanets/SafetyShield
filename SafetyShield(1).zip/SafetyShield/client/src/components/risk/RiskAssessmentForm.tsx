import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage,
  FormDescription 
} from "@/components/ui/form";
import { 
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter 
} from "@/components/ui/card";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue 
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { CalendarIcon, PlusIcon, XIcon } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format, addMonths } from "date-fns";
import { insertRiskAssessmentSchema } from "@shared/schema";
import RiskMatrix from "./RiskMatrix";

// Extended schema for form validation
const riskAssessmentFormSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  location: z.string().min(3, "Location must be at least 3 characters"),
  assessedBy: z.string().min(3, "Assessor name must be at least 3 characters"),
  assessmentDate: z.date(),
  reviewDate: z.date().optional(),
  hazards: z.array(z.object({
    name: z.string().min(3, "Hazard name must be at least 3 characters"),
    description: z.string().min(5, "Description must be at least 5 characters")
  })).min(1, "At least one hazard must be identified"),
  controls: z.array(z.object({
    description: z.string().min(5, "Description must be at least 5 characters")
  })).min(1, "At least one control measure must be identified"),
  likelihood: z.number().min(1).max(5),
  severity: z.number().min(1).max(5),
  status: z.string()
});

type RiskAssessmentFormValues = z.infer<typeof riskAssessmentFormSchema>;

const RiskAssessmentForm = () => {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  
  // Default values for the form
  const defaultValues: Partial<RiskAssessmentFormValues> = {
    title: "",
    description: "",
    location: "",
    assessedBy: "",
    assessmentDate: new Date(),
    reviewDate: addMonths(new Date(), 12), // Default review in 1 year
    hazards: [{ name: "", description: "" }],
    controls: [{ description: "" }],
    likelihood: 3, // Default to middle of the scale
    severity: 3, // Default to middle of the scale
    status: "Draft"
  };
  
  // Define form
  const form = useForm<RiskAssessmentFormValues>({
    resolver: zodResolver(riskAssessmentFormSchema),
    defaultValues,
  });
  
  // Watch likelihood and severity to calculate risk rating
  const likelihood = form.watch("likelihood");
  const severity = form.watch("severity");
  const riskRating = likelihood * severity;
  
  // Handler to add new hazard
  const addHazard = () => {
    const hazards = form.getValues("hazards") || [];
    form.setValue("hazards", [...hazards, { name: "", description: "" }]);
  };
  
  // Handler to remove hazard
  const removeHazard = (index: number) => {
    const hazards = form.getValues("hazards") || [];
    if (hazards.length > 1) {
      form.setValue("hazards", hazards.filter((_, i) => i !== index));
    }
  };
  
  // Handler to add new control
  const addControl = () => {
    const controls = form.getValues("controls") || [];
    form.setValue("controls", [...controls, { description: "" }]);
  };
  
  // Handler to remove control
  const removeControl = (index: number) => {
    const controls = form.getValues("controls") || [];
    if (controls.length > 1) {
      form.setValue("controls", controls.filter((_, i) => i !== index));
    }
  };
  
  // Handle form submission with react-query mutation
  const mutation = useMutation({
    mutationFn: async (values: RiskAssessmentFormValues) => {
      // Calculate risk rating
      const submission = {
        ...values,
        riskRating: values.likelihood * values.severity
      };
      
      const response = await apiRequest("POST", "/api/risk-assessments", submission);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/risk-assessments'] });
      toast({
        title: "Risk assessment saved",
        description: "The risk assessment has been successfully saved.",
      });
      navigate("/risk");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to save risk assessment: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Submit handler
  const onSubmit = (values: RiskAssessmentFormValues) => {
    mutation.mutate(values);
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Conduct Risk Assessment</CardTitle>
        <CardDescription>
          Identify hazards, assess risks, and implement control measures to mitigate them.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Assessment Title</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Enter assessment title" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Where is this assessment for?" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      placeholder="Describe the activity or area being assessed" 
                      rows={3}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <FormField
                control={form.control}
                name="assessedBy"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Assessed By</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Your name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="assessmentDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Assessment Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={`w-full pl-3 text-left font-normal ${!field.value ? "text-muted-foreground" : ""}`}
                          >
                            {field.value ? (
                              format(field.value, "PPP")
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="reviewDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Review Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={`w-full pl-3 text-left font-normal ${!field.value ? "text-muted-foreground" : ""}`}
                          >
                            {field.value ? (
                              format(field.value, "PPP")
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value || undefined}
                          onSelect={field.onChange}
                          disabled={(date) => date < new Date()}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div>
              <h3 className="text-lg font-medium mb-4">Hazard Identification</h3>
              
              {form.getValues("hazards")?.map((_, index) => (
                <div key={index} className="mb-4 p-4 border rounded-lg bg-muted/30">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-sm font-medium">Hazard {index + 1}</h4>
                    {index > 0 && (
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="icon"
                        onClick={() => removeHazard(index)}
                      >
                        <XIcon className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name={`hazards.${index}.name`}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Hazard Name</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="e.g., Slippery Floor" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name={`hazards.${index}.description`}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Briefly describe the hazard" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              ))}
              
              <Button 
                type="button" 
                variant="outline" 
                size="sm" 
                onClick={addHazard}
                className="mt-2"
              >
                <PlusIcon className="h-4 w-4 mr-2" />
                Add Another Hazard
              </Button>
            </div>
            
            <div>
              <h3 className="text-lg font-medium mb-4">Control Measures</h3>
              
              {form.getValues("controls")?.map((_, index) => (
                <div key={index} className="mb-4 p-4 border rounded-lg bg-muted/30">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-sm font-medium">Control Measure {index + 1}</h4>
                    {index > 0 && (
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="icon"
                        onClick={() => removeControl(index)}
                      >
                        <XIcon className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  
                  <FormField
                    control={form.control}
                    name={`controls.${index}.description`}
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Control Measure</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Describe the control measure" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              ))}
              
              <Button 
                type="button" 
                variant="outline" 
                size="sm" 
                onClick={addControl}
                className="mt-2"
              >
                <PlusIcon className="h-4 w-4 mr-2" />
                Add Another Control Measure
              </Button>
            </div>
            
            <div>
              <h3 className="text-lg font-medium mb-4">Risk Rating</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                <FormField
                  control={form.control}
                  name="likelihood"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Likelihood (1-5)</FormLabel>
                      <Select 
                        value={field.value.toString()} 
                        onValueChange={(value) => field.onChange(parseInt(value))}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select likelihood" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="1">1 - Rare</SelectItem>
                          <SelectItem value="2">2 - Unlikely</SelectItem>
                          <SelectItem value="3">3 - Possible</SelectItem>
                          <SelectItem value="4">4 - Likely</SelectItem>
                          <SelectItem value="5">5 - Almost Certain</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        How likely is it that the hazard will cause harm?
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="severity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Severity (1-5)</FormLabel>
                      <Select 
                        value={field.value.toString()} 
                        onValueChange={(value) => field.onChange(parseInt(value))}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select severity" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="1">1 - Negligible</SelectItem>
                          <SelectItem value="2">2 - Minor</SelectItem>
                          <SelectItem value="3">3 - Moderate</SelectItem>
                          <SelectItem value="4">4 - Major</SelectItem>
                          <SelectItem value="5">5 - Severe</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        How serious would the outcome be if the hazard caused harm?
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="bg-muted p-4 rounded-lg">
                <div className="text-sm font-medium mb-2">Risk Matrix</div>
                <RiskMatrix 
                  selectedLikelihood={likelihood}
                  selectedSeverity={severity}
                />
                <div className="mt-3 text-center font-medium">
                  Risk Rating: {riskRating} - {getRiskLevel(riskRating)}
                </div>
              </div>
            </div>
            
            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Status</FormLabel>
                  <Select 
                    defaultValue={field.value} 
                    onValueChange={field.onChange}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Draft">Draft</SelectItem>
                      <SelectItem value="Active">Active</SelectItem>
                      <SelectItem value="Archived">Archived</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </form>
        </Form>
      </CardContent>
      <CardFooter className="flex justify-between border-t pt-6">
        <Button
          type="button"
          variant="outline"
          onClick={() => navigate("/risk")}
        >
          Cancel
        </Button>
        <div className="flex gap-3">
          <Button
            type="button"
            variant="outline"
            onClick={() => form.setValue("status", "Draft")}
          >
            Save as Draft
          </Button>
          <Button
            type="submit"
            onClick={form.handleSubmit(onSubmit)}
            disabled={mutation.isPending}
          >
            {mutation.isPending ? "Saving..." : "Save Assessment"}
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

// Helper function to determine risk level based on risk rating
function getRiskLevel(riskRating: number): string {
  if (riskRating >= 15) return "Critical";
  if (riskRating >= 10) return "High";
  if (riskRating >= 5) return "Medium";
  return "Low";
}

export default RiskAssessmentForm;
