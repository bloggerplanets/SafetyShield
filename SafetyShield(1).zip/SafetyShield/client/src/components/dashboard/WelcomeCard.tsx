import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function WelcomeCard() {
  return (
    <div className="mb-6 bg-white rounded-lg shadow p-4 md:p-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-xl md:text-2xl font-bold text-[#2C3E50]">Welcome to EHS Manager</h1>
          <p className="mt-1 text-gray-500">Your comprehensive workplace safety management system</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Link href="/report-incident">
            <Button className="bg-primary text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-primary/90">
              <i className="ri-add-line mr-1"></i> Report New Incident
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
