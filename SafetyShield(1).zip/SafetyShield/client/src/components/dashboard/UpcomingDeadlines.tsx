import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";

interface StatusBadgeProps {
  status: string;
}

const StatusBadge = ({ status }: StatusBadgeProps) => {
  const statusStyles = {
    "pending": "bg-yellow-100 text-yellow-600",
    "in progress": "bg-blue-100 text-primary",
    "completed": "bg-green-100 text-[#27AE60]",
    "not started": "bg-gray-100 text-gray-600",
    "scheduled": "bg-gray-100 text-gray-600"
  };
  
  const normalizedStatus = status.toLowerCase();
  const style = statusStyles[normalizedStatus as keyof typeof statusStyles] || "bg-gray-100 text-gray-600";
  
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${style}`}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
};

interface TypeBadgeProps {
  type: string;
}

const TypeBadge = ({ type }: TypeBadgeProps) => {
  const typeStyles = {
    "training": "bg-blue-100 text-primary",
    "regulatory": "bg-red-100 text-[#E74C3C]",
    "exercise": "bg-purple-100 text-purple-600",
    "inspection": "bg-green-100 text-[#27AE60]",
    "documentation": "bg-orange-100 text-orange-600"
  };
  
  const normalizedType = type.toLowerCase();
  const style = typeStyles[normalizedType as keyof typeof typeStyles] || "bg-gray-100 text-gray-600";
  
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${style}`}>
      {type}
    </span>
  );
};

export default function UpcomingDeadlines() {
  const { data: deadlines, isLoading } = useQuery({
    queryKey: ['/api/deadlines'],
  });
  
  // Sort deadlines by due date (closest first)
  const sortedDeadlines = deadlines
    ? [...deadlines].sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
    : [];

  return (
    <Card className="mt-6 shadow">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-semibold text-[#2C3E50]">Upcoming Deadlines</CardTitle>
        <Button variant="ghost" size="sm" className="text-sm text-gray-500 hover:text-primary">
          <i className="ri-calendar-line mr-1"></i> View Calendar
        </Button>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          {isLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-8 w-full" />
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Description</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Responsible</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedDeadlines.map((deadline) => {
                  const dueDate = new Date(deadline.dueDate);
                  const isUrgent = dueDate.getTime() - new Date().getTime() < 7 * 24 * 60 * 60 * 1000; // less than 7 days
                  
                  return (
                    <TableRow key={deadline.id}>
                      <TableCell className="font-medium">{deadline.description}</TableCell>
                      <TableCell>
                        <TypeBadge type={deadline.type} />
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <i className={`ri-calendar-check-line ${isUrgent ? 'text-[#E74C3C]' : 'text-gray-500'} mr-2`}></i>
                          <span>{dueDate.toLocaleDateString('en-US', { 
                            year: 'numeric', 
                            month: 'long', 
                            day: 'numeric' 
                          })}</span>
                        </div>
                      </TableCell>
                      <TableCell>{deadline.responsiblePerson}</TableCell>
                      <TableCell>
                        <StatusBadge status={deadline.status} />
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button variant="ghost" size="sm" className="p-1 text-gray-500 hover:text-primary">
                            <i className="ri-eye-line"></i>
                          </Button>
                          <Button variant="ghost" size="sm" className="p-1 text-gray-500 hover:text-primary">
                            <i className="ri-edit-line"></i>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
