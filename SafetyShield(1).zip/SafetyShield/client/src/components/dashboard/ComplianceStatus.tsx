import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { ComplianceItem } from "@shared/schema";

interface ComplianceProgressProps {
  name: string;
  percent: number;
  isYellow?: boolean;
  isRed?: boolean;
}

const ComplianceProgress = ({ name, percent, isYellow = false, isRed = false }: ComplianceProgressProps) => {
  let barColor = "bg-secondary";
  if (isYellow) barColor = "bg-yellow-500";
  if (isRed) barColor = "bg-alert";
  
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <span className="text-sm">{name}</span>
        <span className="text-sm font-medium">{percent}%</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div 
          className={`${barColor} h-2 rounded-full`} 
          style={{ width: `${percent}%` }}
        />
      </div>
    </div>
  );
};

interface ComplianceCategoryProps {
  title: string;
  percent: number;
  items: {
    name: string;
    percent: number;
  }[];
  loading?: boolean;
}

const ComplianceCategory = ({ title, percent, items, loading = false }: ComplianceCategoryProps) => {
  // Determine badge color based on compliance percentage
  let badgeColor = "bg-green-100 text-green-800";
  if (percent < 80) badgeColor = "bg-red-100 text-red-800";
  else if (percent < 90) badgeColor = "bg-yellow-100 text-yellow-800";
  
  return (
    <div className="p-4 border border-gray-200 rounded-lg">
      <div className="flex items-center justify-between mb-4">
        <h4 className="font-medium">{title}</h4>
        {loading ? (
          <Skeleton className="h-5 w-24 rounded-full" />
        ) : (
          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${badgeColor}`}>
            {percent}% Compliant
          </span>
        )}
      </div>
      
      <div className="space-y-3">
        {loading ? (
          <>
            <Skeleton className="h-8 w-full" />
            <Skeleton className="h-8 w-full" />
            <Skeleton className="h-8 w-full" />
            <Skeleton className="h-8 w-full" />
          </>
        ) : (
          items.map((item, index) => (
            <ComplianceProgress 
              key={index} 
              name={item.name} 
              percent={item.percent} 
              isYellow={item.percent < 90 && item.percent >= 80}
              isRed={item.percent < 80}
            />
          ))
        )}
      </div>
    </div>
  );
};

const ComplianceStatus = () => {
  const [department, setDepartment] = useState("all");
  const [timeframe, setTimeframe] = useState("30");
  
  const { data: complianceItems, isLoading } = useQuery<ComplianceItem[]>({
    queryKey: ['/api/compliance'],
  });
  
  // Process compliance data
  const processComplianceData = () => {
    if (!complianceItems) return null;
    
    // Group by standard
    const groupedByStandard: Record<string, ComplianceItem[]> = {};
    
    complianceItems.forEach(item => {
      if (!groupedByStandard[item.standard]) {
        groupedByStandard[item.standard] = [];
      }
      groupedByStandard[item.standard].push(item);
    });
    
    // Calculate averages and prepare data for each standard
    const result: Record<string, { percent: number, items: { name: string, percent: number }[] }> = {};
    
    Object.entries(groupedByStandard).forEach(([standard, items]) => {
      const totalPercent = items.reduce((acc, item) => acc + item.percentComplete, 0);
      const avgPercent = Math.round(totalPercent / items.length);
      
      result[standard] = {
        percent: avgPercent,
        items: items.map(item => ({
          name: item.category,
          percent: item.percentComplete
        }))
      };
    });
    
    return result;
  };
  
  const complianceData = processComplianceData();
  
  return (
    <div className="mt-6 bg-white rounded-lg shadow">
      <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <h3 className="text-lg font-medium">Compliance Status</h3>
          <div className="flex flex-wrap gap-3">
            <Select defaultValue={department} onValueChange={setDepartment}>
              <SelectTrigger className="h-9 w-[180px] text-sm">
                <SelectValue placeholder="Select department" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Departments</SelectItem>
                <SelectItem value="production">Production</SelectItem>
                <SelectItem value="warehouse">Warehouse</SelectItem>
                <SelectItem value="laboratory">Laboratory</SelectItem>
                <SelectItem value="office">Office</SelectItem>
              </SelectContent>
            </Select>
            
            <Select defaultValue={timeframe} onValueChange={setTimeframe}>
              <SelectTrigger className="h-9 w-[180px] text-sm">
                <SelectValue placeholder="Select timeframe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="30">Last 30 Days</SelectItem>
                <SelectItem value="90">Last Quarter</SelectItem>
                <SelectItem value="365">Year to Date</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
      
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {isLoading ? (
            <>
              <ComplianceCategory 
                title="OSHA Standards" 
                percent={0} 
                items={[]}
                loading={true} 
              />
              <ComplianceCategory 
                title="ISO 45001" 
                percent={0} 
                items={[]}
                loading={true} 
              />
              <ComplianceCategory 
                title="Internal Policies" 
                percent={0} 
                items={[]}
                loading={true} 
              />
            </>
          ) : complianceData ? (
            <>
              {complianceData['OSHA'] && (
                <ComplianceCategory 
                  title="OSHA Standards" 
                  percent={complianceData['OSHA'].percent} 
                  items={complianceData['OSHA'].items} 
                />
              )}
              
              {complianceData['ISO 45001'] && (
                <ComplianceCategory 
                  title="ISO 45001" 
                  percent={complianceData['ISO 45001'].percent} 
                  items={complianceData['ISO 45001'].items} 
                />
              )}
              
              {complianceData['Internal'] && (
                <ComplianceCategory 
                  title="Internal Policies" 
                  percent={complianceData['Internal'].percent} 
                  items={complianceData['Internal'].items} 
                />
              )}
            </>
          ) : (
            <div className="col-span-3 text-center py-8 text-gray-500">
              No compliance data available
            </div>
          )}
        </div>
      </div>
      
      <div className="px-4 py-3 bg-gray-50 text-right rounded-b-lg">
        <a href="#" className="text-sm font-medium text-primary hover:text-primary-dark">
          View detailed compliance report
        </a>
      </div>
    </div>
  );
};

export default ComplianceStatus;
