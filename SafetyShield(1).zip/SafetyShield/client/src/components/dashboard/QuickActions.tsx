import { Link } from "wouter";
import { PlusCircleIcon, FilePlus, AlertTriangleIcon, ClipboardCheckIcon, ChevronRightIcon } from "lucide-react";

const QuickActions = () => {
  return (
    <div className="bg-white rounded-lg shadow">
      <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
        <h3 className="text-lg font-medium">Quick Actions</h3>
      </div>
      <div className="p-4 space-y-3">
        <Link href="/incidents/report">
          <a className="flex items-center justify-between p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
            <div className="flex items-center">
              <PlusCircleIcon className="w-5 h-5 text-primary mr-3" />
              <span className="font-medium">Report New Incident</span>
            </div>
            <ChevronRightIcon className="w-5 h-5 text-gray-400" />
          </a>
        </Link>
        
        <Link href="/documents">
          <a className="flex items-center justify-between p-3 bg-green-50 rounded-lg hover:bg-green-100 transition-colors">
            <div className="flex items-center">
              <FilePlus className="w-5 h-5 text-secondary mr-3" />
              <span className="font-medium">Upload Document</span>
            </div>
            <ChevronRightIcon className="w-5 h-5 text-gray-400" />
          </a>
        </Link>
        
        <Link href="/risk">
          <a className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg hover:bg-yellow-100 transition-colors">
            <div className="flex items-center">
              <AlertTriangleIcon className="w-5 h-5 text-yellow-600 mr-3" />
              <span className="font-medium">Conduct Risk Assessment</span>
            </div>
            <ChevronRightIcon className="w-5 h-5 text-gray-400" />
          </a>
        </Link>
        
        <a href="#" className="flex items-center justify-between p-3 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors">
          <div className="flex items-center">
            <ClipboardCheckIcon className="w-5 h-5 text-purple-600 mr-3" />
            <span className="font-medium">Schedule Audit</span>
          </div>
          <ChevronRightIcon className="w-5 h-5 text-gray-400" />
        </a>
      </div>
    </div>
  );
};

export default QuickActions;
