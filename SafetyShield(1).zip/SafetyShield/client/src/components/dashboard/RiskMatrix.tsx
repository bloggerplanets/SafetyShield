import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";

const RiskCell = ({ level, label, hasRisk = false, riskColor = "" }: { 
  level: string, 
  label: string, 
  hasRisk?: boolean, 
  riskColor?: string 
}) => {
  let bgColor = "";
  
  switch (level) {
    case "low":
      bgColor = "bg-green-100";
      break;
    case "medium":
      bgColor = "bg-yellow-100";
      break;
    case "high":
      bgColor = "bg-orange-100";
      break;
    case "extreme":
      bgColor = "bg-red-100";
      break;
    default:
      bgColor = "bg-gray-100";
  }
  
  return (
    <div className={`${bgColor} p-3 text-center relative`}>
      <span className="text-xs">{label}</span>
      {hasRisk && (
        <div className={`absolute top-1 right-1 w-3 h-3 ${riskColor} rounded-full`}></div>
      )}
    </div>
  );
};

export default function RiskMatrix() {
  const { data: risks, isLoading } = useQuery({
    queryKey: ['/api/risks'],
  });
  
  // Find risk items for the matrix dots
  const findRisk = (likelihood: string, impact: string) => {
    if (!risks) return null;
    return risks.find((risk: any) => 
      risk.likelihood.toLowerCase() === likelihood && 
      risk.impact.toLowerCase() === impact
    );
  };
  
  // Map risks to their positions in the matrix
  const chemicalExposure = findRisk("certain", "major");
  const equipmentMalfunction = findRisk("possible", "minor");
  const tripHazards = findRisk("unlikely", "negligible");

  return (
    <Card className="mt-6 shadow">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-semibold text-[#2C3E50]">Risk Assessment Matrix</CardTitle>
        <Link href="/risk-assessment">
          <Button variant="link" className="text-sm text-primary hover:underline">View Risk Register</Button>
        </Link>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <Skeleton className="h-[300px] w-full rounded-md" />
        ) : (
          <>
            <div className="overflow-x-auto">
              <div className="min-w-[600px]">
                <div className="grid grid-cols-6 gap-1">
                  <div className="col-span-1"></div>
                  <div className="col-span-5 grid grid-cols-5 gap-1">
                    <div className="bg-gray-100 p-2 text-center text-sm font-medium">Negligible</div>
                    <div className="bg-gray-100 p-2 text-center text-sm font-medium">Minor</div>
                    <div className="bg-gray-100 p-2 text-center text-sm font-medium">Moderate</div>
                    <div className="bg-gray-100 p-2 text-center text-sm font-medium">Major</div>
                    <div className="bg-gray-100 p-2 text-center text-sm font-medium">Severe</div>
                  </div>
                  
                  {/* Certain Row */}
                  <div className="bg-gray-100 p-2 flex items-center justify-center">
                    <span className="transform -rotate-90 whitespace-nowrap text-sm font-medium">Certain</span>
                  </div>
                  <RiskCell level="medium" label="Medium" />
                  <RiskCell level="high" label="High" />
                  <RiskCell level="extreme" label="Extreme" hasRisk={!!chemicalExposure} riskColor="bg-[#E74C3C]" />
                  <RiskCell level="extreme" label="Extreme" />
                  <RiskCell level="extreme" label="Extreme" />
                  
                  {/* Likely Row */}
                  <div className="bg-gray-100 p-2 flex items-center justify-center">
                    <span className="transform -rotate-90 whitespace-nowrap text-sm font-medium">Likely</span>
                  </div>
                  <RiskCell level="low" label="Low" />
                  <RiskCell level="medium" label="Medium" />
                  <RiskCell level="high" label="High" />
                  <RiskCell level="extreme" label="Extreme" />
                  <RiskCell level="extreme" label="Extreme" />
                  
                  {/* Possible Row */}
                  <div className="bg-gray-100 p-2 flex items-center justify-center">
                    <span className="transform -rotate-90 whitespace-nowrap text-sm font-medium">Possible</span>
                  </div>
                  <RiskCell level="low" label="Low" />
                  <RiskCell level="medium" label="Medium" hasRisk={!!equipmentMalfunction} riskColor="bg-orange-500" />
                  <RiskCell level="high" label="High" />
                  <RiskCell level="high" label="High" />
                  <RiskCell level="extreme" label="Extreme" />
                  
                  {/* Unlikely Row */}
                  <div className="bg-gray-100 p-2 flex items-center justify-center">
                    <span className="transform -rotate-90 whitespace-nowrap text-sm font-medium">Unlikely</span>
                  </div>
                  <RiskCell level="low" label="Low" hasRisk={!!tripHazards} riskColor="bg-[#27AE60]" />
                  <RiskCell level="low" label="Low" />
                  <RiskCell level="medium" label="Medium" />
                  <RiskCell level="high" label="High" />
                  <RiskCell level="high" label="High" />
                  
                  {/* Rare Row */}
                  <div className="bg-gray-100 p-2 flex items-center justify-center">
                    <span className="transform -rotate-90 whitespace-nowrap text-sm font-medium">Rare</span>
                  </div>
                  <RiskCell level="low" label="Low" />
                  <RiskCell level="low" label="Low" />
                  <RiskCell level="low" label="Low" />
                  <RiskCell level="medium" label="Medium" />
                  <RiskCell level="high" label="High" />
                </div>
              </div>
            </div>
            
            <div className="mt-4">
              <h3 className="text-sm font-medium mb-2">Current Risk Items:</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                {risks?.map((risk: any) => (
                  <div key={risk.id} className="flex items-center">
                    <span className={`w-3 h-3 rounded-full mr-2 ${
                      risk.riskLevel === 'high' || risk.riskLevel === 'extreme' 
                        ? 'bg-[#E74C3C]' 
                        : risk.riskLevel === 'medium' 
                          ? 'bg-orange-500' 
                          : 'bg-[#27AE60]'
                    }`}></span>
                    <span className="text-sm">{risk.title}</span>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
