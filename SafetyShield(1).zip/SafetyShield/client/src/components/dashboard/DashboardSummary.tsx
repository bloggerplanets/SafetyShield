import { AlertCircleIcon, CheckCircleIcon, ClockIcon, CalendarIcon } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";

interface SummaryCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  iconBgColor: string;
  footerText: string;
  changeText: string;
  changeTextColor: string;
  loading?: boolean;
}

const SummaryCard = ({ 
  title, 
  value, 
  icon, 
  iconBgColor,
  footerText,
  changeText,
  changeTextColor,
  loading = false
}: SummaryCardProps) => {
  return (
    <div className="dashboard-card bg-white rounded-lg shadow p-4 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-gray-500">{title}</p>
          {loading ? (
            <Skeleton className="h-8 w-16 mt-1" />
          ) : (
            <p className="text-2xl font-semibold mt-1">{value}</p>
          )}
        </div>
        <div className={`p-2 ${iconBgColor} rounded-lg`}>
          {icon}
        </div>
      </div>
      <div className="mt-4">
        {loading ? (
          <Skeleton className="h-4 w-full" />
        ) : (
          <div className="flex items-center justify-between">
            <span className="text-xs text-gray-500">{footerText}</span>
            <span className={`text-xs font-medium ${changeTextColor}`}>{changeText}</span>
          </div>
        )}
      </div>
    </div>
  );
};

const DashboardSummary = () => {
  // Fetch incidents to count open ones
  const { data: incidents, isLoading: isLoadingIncidents } = useQuery({
    queryKey: ['/api/incidents'],
  });
  
  // Fetch compliance items to calculate compliance score
  const { data: complianceItems, isLoading: isLoadingCompliance } = useQuery({
    queryKey: ['/api/compliance'],
  });
  
  // Fetch tasks to count overdue items
  const { data: tasks, isLoading: isLoadingTasks } = useQuery({
    queryKey: ['/api/tasks'],
  });
  
  // Fetch audits to count upcoming ones
  const { data: audits, isLoading: isLoadingAudits } = useQuery({
    queryKey: ['/api/audits'],
  });
  
  // Calculate summary metrics
  const openIncidents = incidents?.filter(i => i.status !== 'Closed')?.length || 0;
  const highPriorityIncidents = incidents?.filter(i => i.status !== 'Closed' && i.severity === 'High')?.length || 0;
  
  // Calculate compliance score (average of percentComplete)
  const complianceScore = complianceItems?.length 
    ? Math.round(complianceItems.reduce((acc, item) => acc + item.percentComplete, 0) / complianceItems.length) 
    : 0;
  
  // Calculate overdue items
  const overdueItems = tasks?.filter(task => {
    const dueDate = new Date(task.dueDate);
    return dueDate < new Date() && task.status !== 'Completed';
  })?.length || 0;
  
  // Calculate upcoming audits
  const upcomingAudits = audits?.filter(audit => {
    const scheduledDate = new Date(audit.scheduledDate);
    const now = new Date();
    const inNextMonth = new Date(now);
    inNextMonth.setMonth(inNextMonth.getMonth() + 1);
    return scheduledDate > now && scheduledDate < inNextMonth && audit.status === 'Scheduled';
  })?.length || 0;
  
  // Get next audit date
  const nextAudit = audits?.find(audit => {
    const scheduledDate = new Date(audit.scheduledDate);
    return scheduledDate > new Date() && audit.status === 'Scheduled';
  });
  
  // Format next audit date
  const formatAuditDate = () => {
    if (!nextAudit) return 'None scheduled';
    
    const date = new Date(nextAudit.scheduledDate);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };
  
  // Calculate days until next audit
  const daysUntilNextAudit = () => {
    if (!nextAudit) return '0';
    
    const now = new Date();
    const auditDate = new Date(nextAudit.scheduledDate);
    const diffTime = Math.abs(auditDate.getTime() - now.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return `In ${diffDays} days`;
  };
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      <SummaryCard 
        title="Open Incidents"
        value={openIncidents}
        icon={<AlertCircleIcon className="w-6 h-6 text-alert" />}
        iconBgColor="bg-red-100"
        footerText={`${highPriorityIncidents} require immediate action`}
        changeText="+2 from last week"
        changeTextColor="text-alert"
        loading={isLoadingIncidents}
      />
      
      <SummaryCard 
        title="Compliance Score"
        value={`${complianceScore}%`}
        icon={<CheckCircleIcon className="w-6 h-6 text-secondary" />}
        iconBgColor="bg-green-100"
        footerText="Target: 95%"
        changeText="+3% from last month"
        changeTextColor="text-secondary"
        loading={isLoadingCompliance}
      />
      
      <SummaryCard 
        title="Overdue Items"
        value={overdueItems}
        icon={<ClockIcon className="w-6 h-6 text-yellow-500" />}
        iconBgColor="bg-yellow-100"
        footerText="Oldest: 12 days"
        changeText="-2 from last week"
        changeTextColor="text-yellow-500"
        loading={isLoadingTasks}
      />
      
      <SummaryCard 
        title="Upcoming Audits"
        value={upcomingAudits}
        icon={<CalendarIcon className="w-6 h-6 text-primary" />}
        iconBgColor="bg-blue-100"
        footerText={`Next: ${formatAuditDate()}`}
        changeText={daysUntilNextAudit()}
        changeTextColor="text-primary"
        loading={isLoadingAudits}
      />
    </div>
  );
};

export default DashboardSummary;
