import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { Task } from "@shared/schema";

interface PriorityBadgeProps {
  priority: string;
}

const PriorityBadge = ({ priority }: PriorityBadgeProps) => {
  let bgColor = "bg-gray-100 text-gray-800";
  
  switch (priority.toLowerCase()) {
    case "high":
      bgColor = "bg-red-100 text-red-800";
      break;
    case "medium":
      bgColor = "bg-yellow-100 text-yellow-800";
      break;
    case "low":
      bgColor = "bg-green-100 text-green-800";
      break;
  }
  
  return (
    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${bgColor}`}>
      {priority} Priority
    </span>
  );
};

const TasksLoading = () => (
  <ul className="divide-y divide-gray-200">
    {[...Array(4)].map((_, i) => (
      <li key={i} className="py-3">
        <div className="flex items-start">
          <div className="min-w-0 flex-1">
            <Skeleton className="h-4 w-full max-w-[250px] mb-2" />
            <Skeleton className="h-4 w-32" />
          </div>
          <div className="ml-4 flex-shrink-0">
            <Skeleton className="h-5 w-20 rounded-full" />
          </div>
        </div>
      </li>
    ))}
  </ul>
);

const UpcomingTasks = () => {
  const { data: tasks, isLoading } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
  });
  
  // Sort by due date (soonest first) and filter out completed tasks
  const upcomingTasks = tasks
    ? [...tasks]
        .filter(task => task.status !== 'Completed')
        .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
        .slice(0, 4)
    : [];
  
  return (
    <div className="bg-white rounded-lg shadow">
      <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
        <h3 className="text-lg font-medium">Upcoming Tasks</h3>
      </div>
      <div className="p-4">
        {isLoading ? (
          <TasksLoading />
        ) : (
          <ul className="divide-y divide-gray-200">
            {upcomingTasks.map((task) => (
              <li key={task.id} className="py-3">
                <div className="flex items-start">
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium">{task.title}</p>
                    <p className="text-sm text-gray-500">
                      Due: {format(new Date(task.dueDate), 'MMM d, yyyy')}
                    </p>
                  </div>
                  <div className="ml-4 flex-shrink-0">
                    <PriorityBadge priority={task.priority} />
                  </div>
                </div>
              </li>
            ))}
            
            {upcomingTasks.length === 0 && (
              <li className="py-3 text-center text-sm text-gray-500">
                No upcoming tasks
              </li>
            )}
          </ul>
        )}
      </div>
      <div className="px-4 py-3 bg-gray-50 text-right rounded-b-lg">
        <a href="#" className="text-sm font-medium text-primary hover:text-primary-dark">
          View all tasks
        </a>
      </div>
    </div>
  );
};

export default UpcomingTasks;
