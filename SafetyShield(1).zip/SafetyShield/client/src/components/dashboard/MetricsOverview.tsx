import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";

interface MetricCardProps {
  title: string;
  value: string | number;
  icon: string;
  iconBgClass: string;
  iconColor: string;
  changeText?: string;
  changeIcon?: string;
  changeColor?: string;
  changeInfo?: string;
}

const MetricCard = ({
  title,
  value,
  icon,
  iconBgClass,
  iconColor,
  changeText,
  changeIcon,
  changeColor,
  changeInfo
}: MetricCardProps) => (
  <Card className="shadow">
    <CardContent className="p-4">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium text-gray-500">{title}</p>
        <span className={`p-2 rounded-full ${iconBgClass} ${iconColor}`}>
          <i className={icon}></i>
        </span>
      </div>
      <p className="mt-2 text-2xl font-bold text-[#2C3E50]">{value}</p>
      {changeText && (
        <div className="flex items-center mt-2">
          <span className={`text-sm ${changeColor} flex items-center`}>
            <i className={`${changeIcon} mr-1`}></i> {changeText}
          </span>
          {changeInfo && <span className="text-xs text-gray-500 ml-2">{changeInfo}</span>}
        </div>
      )}
    </CardContent>
  </Card>
);

const MetricCardSkeleton = () => (
  <Card className="shadow">
    <CardContent className="p-4">
      <div className="flex items-center justify-between">
        <Skeleton className="h-4 w-24" />
        <Skeleton className="h-8 w-8 rounded-full" />
      </div>
      <Skeleton className="h-8 w-16 mt-2" />
      <div className="flex items-center mt-2">
        <Skeleton className="h-4 w-20" />
      </div>
    </CardContent>
  </Card>
);

export default function MetricsOverview() {
  const { data: incidents, isLoading: incidentsLoading } = useQuery({
    queryKey: ['/api/incidents'],
  });
  
  const { data: compliance, isLoading: complianceLoading } = useQuery({
    queryKey: ['/api/compliance'],
  });
  
  const { data: deadlines, isLoading: deadlinesLoading } = useQuery({
    queryKey: ['/api/deadlines'],
  });
  
  // Calculate compliance rate
  const complianceRate = compliance?.length
    ? Math.round((compliance.filter((item: any) => item.status === 'compliant').length / compliance.length) * 100)
    : 0;
  
  const isLoading = incidentsLoading || complianceLoading || deadlinesLoading;
  
  const openInvestigations = incidents?.filter((incident: any) => 
    incident.status === 'investigating'
  ).length || 0;
  
  const upcomingDeadlines = deadlines?.length || 0;
  const closestDeadline = deadlines?.sort((a: any, b: any) => 
    new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
  )[0];
  
  const daysToNextDeadline = closestDeadline 
    ? Math.ceil((new Date(closestDeadline.dueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
    : null;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {isLoading ? (
        <>
          <MetricCardSkeleton />
          <MetricCardSkeleton />
          <MetricCardSkeleton />
          <MetricCardSkeleton />
        </>
      ) : (
        <>
          <MetricCard
            title="Total Incidents"
            value={incidents?.length || 0}
            icon="ri-error-warning-line"
            iconBgClass="bg-primary/10"
            iconColor="text-primary"
            changeText="12%"
            changeIcon="ri-arrow-down-line"
            changeColor="text-[#27AE60]"
            changeInfo="vs last month"
          />
          
          <MetricCard
            title="Open Investigations"
            value={openInvestigations}
            icon="ri-search-line"
            iconBgClass="bg-[#E74C3C]/10"
            iconColor="text-[#E74C3C]"
            changeText="3%"
            changeIcon="ri-arrow-up-line"
            changeColor="text-[#E74C3C]"
            changeInfo="vs last month"
          />
          
          <MetricCard
            title="Compliance Rate"
            value={`${complianceRate}%`}
            icon="ri-checkbox-circle-line"
            iconBgClass="bg-[#27AE60]/10"
            iconColor="text-[#27AE60]"
            changeText="2%"
            changeIcon="ri-arrow-up-line"
            changeColor="text-[#27AE60]"
            changeInfo="vs last month"
          />
          
          <MetricCard
            title="Upcoming Deadlines"
            value={upcomingDeadlines}
            icon="ri-calendar-event-line"
            iconBgClass="bg-yellow-100"
            iconColor="text-yellow-600"
            changeText={daysToNextDeadline ? `Next in ${daysToNextDeadline} days` : "No deadlines"}
            changeIcon="ri-time-line"
            changeColor="text-yellow-600"
          />
        </>
      )}
    </div>
  );
}
