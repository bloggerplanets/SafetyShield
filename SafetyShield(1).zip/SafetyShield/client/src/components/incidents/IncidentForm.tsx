import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { 
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle 
} from "@/components/ui/card";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue 
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { insertIncidentSchema } from "@shared/schema";

// Extend the insertIncidentSchema for the form with validation
const incidentFormSchema = insertIncidentSchema.extend({
  description: z.string().min(10, "Description must be at least 10 characters"),
  location: z.string().min(3, "Location must be at least 3 characters"),
  reportedBy: z.string().min(3, "Reporter name must be at least 3 characters"),
});

type IncidentFormValues = z.infer<typeof incidentFormSchema>;

const IncidentForm = () => {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  
  // Generate a default incident ID in the format INC-YYYY-XXX
  const generateIncidentId = () => {
    const year = new Date().getFullYear();
    const randomNum = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `INC-${year}-${randomNum}`;
  };
  
  // Default values for the form
  const defaultValues: Partial<IncidentFormValues> = {
    incidentId: generateIncidentId(),
    type: "Near Miss",
    description: "",
    location: "",
    reportedBy: "",
    reportedDate: new Date(),
    status: "Open",
    severity: "Medium",
  };
  
  // Define form
  const form = useForm<IncidentFormValues>({
    resolver: zodResolver(incidentFormSchema),
    defaultValues,
  });
  
  // Handle form submission with react-query mutation
  const mutation = useMutation({
    mutationFn: async (values: IncidentFormValues) => {
      const response = await apiRequest("POST", "/api/incidents", values);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/incidents'] });
      toast({
        title: "Incident reported",
        description: "The incident has been successfully reported.",
      });
      navigate("/incidents");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to report incident: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Submit handler
  const onSubmit = (values: IncidentFormValues) => {
    // Create a new payload to avoid mutation of the original values
    const payload = {
      ...values,
      // Convert Date objects to ISO strings for proper JSON handling
      reportedDate: values.reportedDate.toISOString(),
      // Convert optional dates if they exist
      ...(values.dueDate && { dueDate: values.dueDate.toISOString() }),
      ...(values.closedDate && { closedDate: values.closedDate.toISOString() }),
    };
    
    console.log("Submitting incident with payload:", payload);
    mutation.mutate(payload);
  };
  
  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle>Report an Incident</CardTitle>
        <CardDescription>
          Use this form to report accidents, near-misses, or hazards in the workplace.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="incidentId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Incident ID</FormLabel>
                    <FormControl>
                      <Input {...field} disabled />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Incident Type</FormLabel>
                    <Select 
                      defaultValue={field.value} 
                      onValueChange={field.onChange}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select incident type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Accident">Accident</SelectItem>
                        <SelectItem value="Near Miss">Near Miss</SelectItem>
                        <SelectItem value="Hazard">Hazard</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      placeholder="Describe what happened in detail" 
                      rows={4}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="location"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Location</FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      placeholder="Where did the incident occur?" 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="reportedBy"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reported By</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        placeholder="Your name" 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="severity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Severity</FormLabel>
                    <Select 
                      defaultValue={field.value} 
                      onValueChange={field.onChange}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select severity" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Low">Low</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="High">High</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            {/* Hidden field for reported date - handled in submit handler */}
            
            <div className="flex justify-end gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate("/incidents")}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={mutation.isPending}>
                {mutation.isPending ? "Submitting..." : "Submit Report"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};

export default IncidentForm;
