import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { Incident } from "@shared/schema";
import { 
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle 
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue 
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { PlusIcon, SearchIcon } from "lucide-react";

interface StatusBadgeProps {
  status: string;
}

const StatusBadge = ({ status }: StatusBadgeProps) => {
  let bgColor = "bg-gray-100 text-gray-800";
  
  switch (status.toLowerCase()) {
    case "open":
      bgColor = "bg-red-100 text-red-800";
      break;
    case "in progress":
      bgColor = "bg-yellow-100 text-yellow-800";
      break;
    case "closed":
      bgColor = "bg-green-100 text-green-800";
      break;
  }
  
  return (
    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${bgColor}`}>
      {status}
    </span>
  );
};

interface SeverityBadgeProps {
  severity: string;
}

const SeverityBadge = ({ severity }: SeverityBadgeProps) => {
  let bgColor = "bg-gray-100 text-gray-800";
  
  switch (severity.toLowerCase()) {
    case "high":
      bgColor = "bg-red-100 text-red-800";
      break;
    case "medium":
      bgColor = "bg-yellow-100 text-yellow-800";
      break;
    case "low":
      bgColor = "bg-green-100 text-green-800";
      break;
  }
  
  return (
    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${bgColor}`}>
      {severity}
    </span>
  );
};

const LoadingSkeleton = () => (
  <div className="space-y-2">
    {[...Array(5)].map((_, i) => (
      <TableRow key={i}>
        <TableCell><Skeleton className="h-4 w-24" /></TableCell>
        <TableCell><Skeleton className="h-4 w-20" /></TableCell>
        <TableCell className="max-w-[200px]"><Skeleton className="h-4 w-full" /></TableCell>
        <TableCell><Skeleton className="h-4 w-28" /></TableCell>
        <TableCell><Skeleton className="h-4 w-24" /></TableCell>
        <TableCell><Skeleton className="h-5 w-16 rounded-full" /></TableCell>
        <TableCell><Skeleton className="h-5 w-16 rounded-full" /></TableCell>
      </TableRow>
    ))}
  </div>
);

const IncidentList = () => {
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  
  const { data: incidents, isLoading } = useQuery<Incident[]>({
    queryKey: ['/api/incidents'],
  });
  
  // Filter incidents based on selected filters and search query
  const filteredIncidents = incidents?.filter(incident => {
    // Apply status filter
    if (statusFilter !== "all" && incident.status !== statusFilter) {
      return false;
    }
    
    // Apply type filter
    if (typeFilter !== "all" && incident.type !== typeFilter) {
      return false;
    }
    
    // Apply search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        incident.incidentId.toLowerCase().includes(query) ||
        incident.description.toLowerCase().includes(query) ||
        incident.location.toLowerCase().includes(query) ||
        incident.reportedBy.toLowerCase().includes(query)
      );
    }
    
    return true;
  }) || [];
  
  // Sort incidents by reported date (newest first)
  const sortedIncidents = [...filteredIncidents].sort((a, b) => 
    new Date(b.reportedDate).getTime() - new Date(a.reportedDate).getTime()
  );
  
  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <CardTitle>Incident Dashboard</CardTitle>
            <CardDescription>
              View and manage all reported incidents
            </CardDescription>
          </div>
          <Link href="/incidents/report">
            <Button>
              <PlusIcon className="w-4 h-4 mr-2" />
              Report Incident
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-grow max-w-sm">
            <div className="relative">
              <SearchIcon className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Search incidents..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          <div className="flex flex-wrap gap-3">
            <Select defaultValue={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="Open">Open</SelectItem>
                <SelectItem value="In Progress">In Progress</SelectItem>
                <SelectItem value="Closed">Closed</SelectItem>
              </SelectContent>
            </Select>
            
            <Select defaultValue={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="Accident">Accident</SelectItem>
                <SelectItem value="Near Miss">Near Miss</SelectItem>
                <SelectItem value="Hazard">Hazard</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Reported Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Severity</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <LoadingSkeleton />
              ) : sortedIncidents.length > 0 ? (
                sortedIncidents.map((incident) => (
                  <TableRow key={incident.id} className="hover:bg-muted/50">
                    <TableCell className="font-medium">{incident.incidentId}</TableCell>
                    <TableCell>{incident.type}</TableCell>
                    <TableCell className="max-w-[200px] truncate">{incident.description}</TableCell>
                    <TableCell>{incident.location}</TableCell>
                    <TableCell>{format(new Date(incident.reportedDate), 'MMM d, yyyy')}</TableCell>
                    <TableCell>
                      <StatusBadge status={incident.status} />
                    </TableCell>
                    <TableCell>
                      <SeverityBadge severity={incident.severity} />
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-6 text-gray-500">
                    {searchQuery || statusFilter !== 'all' || typeFilter !== 'all'
                      ? "No incidents match your filters"
                      : "No incidents have been reported yet"}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default IncidentList;
