import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue 
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { FilterIcon, PlusIcon } from "lucide-react";
import { ComplianceItem } from "@shared/schema";
import { format } from "date-fns";

interface StatusBadgeProps {
  status: string;
}

const StatusBadge = ({ status }: StatusBadgeProps) => {
  let variant: "outline" | "default" | "secondary" | "destructive" = "outline";
  
  switch (status.toLowerCase()) {
    case "compliant":
      variant = "default";
      break;
    case "non-compliant":
      variant = "destructive";
      break;
    case "in progress":
      variant = "secondary";
      break;
  }
  
  return <Badge variant={variant}>{status}</Badge>;
};

interface ProgressWithLabelProps {
  value: number;
  showValue?: boolean;
}

const ProgressWithLabel = ({ value, showValue = true }: ProgressWithLabelProps) => {
  let color = "bg-secondary";
  if (value < 80) color = "bg-alert";
  else if (value < 90) color = "bg-yellow-500";
  
  return (
    <div className="space-y-1">
      <Progress value={value} className={color} />
      {showValue && (
        <div className="text-right text-xs text-muted-foreground">{value}%</div>
      )}
    </div>
  );
};

const LoadingSkeleton = () => (
  <div className="space-y-2">
    {[...Array(5)].map((_, i) => (
      <TableRow key={i}>
        <TableCell><Skeleton className="h-4 w-40" /></TableCell>
        <TableCell><Skeleton className="h-4 w-24" /></TableCell>
        <TableCell><Skeleton className="h-4 w-24" /></TableCell>
        <TableCell><Skeleton className="h-3 w-full" /></TableCell>
        <TableCell><Skeleton className="h-5 w-20 rounded-full" /></TableCell>
        <TableCell><Skeleton className="h-4 w-24" /></TableCell>
      </TableRow>
    ))}
  </div>
);

const ComplianceTracker = () => {
  const [standardFilter, setStandardFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  
  const { data: complianceItems, isLoading } = useQuery<ComplianceItem[]>({
    queryKey: ['/api/compliance'],
  });
  
  // Filter compliance items based on selected filters
  const filteredItems = complianceItems?.filter(item => {
    // Apply standard filter
    if (standardFilter !== "all" && item.standard !== standardFilter) {
      return false;
    }
    
    // Apply category filter
    if (categoryFilter !== "all" && item.category !== categoryFilter) {
      return false;
    }
    
    // Apply status filter
    if (statusFilter !== "all" && item.status !== statusFilter) {
      return false;
    }
    
    return true;
  }) || [];
  
  // Extract unique categories for the filter
  const uniqueCategories = Array.from(
    new Set(complianceItems?.map(item => item.category) || [])
  ).sort();
  
  // Calculate overall compliance percentage
  const overallCompliance = filteredItems.length
    ? Math.round(
        filteredItems.reduce((acc, item) => acc + item.percentComplete, 0) / 
        filteredItems.length
      )
    : 0;
  
  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <CardTitle>Compliance Tracking</CardTitle>
            <CardDescription>
              Monitor and track compliance status across all standards and requirements
            </CardDescription>
          </div>
          <Button>
            <PlusIcon className="w-4 h-4 mr-2" />
            Add Compliance Item
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col mb-6">
          <div className="flex flex-col md:flex-row gap-4 items-start md:items-center mb-6">
            <div className="text-sm font-medium">Overall Compliance:</div>
            <div className="flex-1 max-w-md">
              {isLoading ? (
                <Skeleton className="h-4 w-full" />
              ) : (
                <ProgressWithLabel value={overallCompliance} />
              )}
            </div>
            <div className="flex flex-wrap gap-3">
              <Button variant="outline" size="sm" className="h-9">
                <FilterIcon className="w-4 h-4 mr-2" />
                Filters
              </Button>
              <Select defaultValue={standardFilter} onValueChange={setStandardFilter}>
                <SelectTrigger className="w-[160px] h-9">
                  <SelectValue placeholder="Standard" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Standards</SelectItem>
                  <SelectItem value="OSHA">OSHA</SelectItem>
                  <SelectItem value="ISO 45001">ISO 45001</SelectItem>
                  <SelectItem value="Internal">Internal</SelectItem>
                </SelectContent>
              </Select>
              
              <Select defaultValue={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[160px] h-9">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="Compliant">Compliant</SelectItem>
                  <SelectItem value="Non-Compliant">Non-Compliant</SelectItem>
                  <SelectItem value="In Progress">In Progress</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {categoryFilter !== "all" && uniqueCategories.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-4">
              <Select defaultValue={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-[200px] h-9">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {uniqueCategories.map(category => (
                    <SelectItem key={category} value={category}>{category}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Requirement</TableHead>
                <TableHead>Standard</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Progress</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Due Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <LoadingSkeleton />
              ) : filteredItems.length > 0 ? (
                filteredItems.map((item) => (
                  <TableRow key={item.id} className="hover:bg-muted/50">
                    <TableCell className="font-medium">{item.name}</TableCell>
                    <TableCell>{item.standard}</TableCell>
                    <TableCell>{item.category}</TableCell>
                    <TableCell className="max-w-[200px]">
                      <ProgressWithLabel value={item.percentComplete} />
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={item.status} />
                    </TableCell>
                    <TableCell>
                      {item.dueDate 
                        ? format(new Date(item.dueDate), 'MMM d, yyyy')
                        : "No deadline"
                      }
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-6 text-gray-500">
                    {standardFilter !== 'all' || categoryFilter !== 'all' || statusFilter !== 'all'
                      ? "No compliance items match your filters"
                      : "No compliance items have been added yet"}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
      <CardFooter className="border-t bg-muted/50 flex justify-between">
        <div className="text-sm text-muted-foreground">
          Showing {filteredItems.length} of {complianceItems?.length || 0} items
        </div>
        <Button variant="outline" size="sm">
          Generate Report
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ComplianceTracker;
