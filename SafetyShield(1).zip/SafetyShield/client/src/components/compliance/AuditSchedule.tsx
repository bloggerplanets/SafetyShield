import { useQuery } from "@tanstack/react-query";
import { Audit } from "@shared/schema";
import { format, isFuture, isPast, isToday } from "date-fns";
import { 
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { CalendarIcon, ClipboardCheckIcon, ClipboardIcon, PlusIcon } from "lucide-react";
import { useState } from "react";

interface StatusBadgeProps {
  status: string;
}

const StatusBadge = ({ status }: StatusBadgeProps) => {
  let variant: "outline" | "default" | "secondary" | "destructive" = "outline";
  
  switch (status.toLowerCase()) {
    case "scheduled":
      variant = "secondary";
      break;
    case "in progress":
      variant = "default";
      break;
    case "completed":
      variant = "outline";
      break;
  }
  
  return <Badge variant={variant}>{status}</Badge>;
};

interface AuditCardProps {
  audit: Audit;
}

const AuditCard = ({ audit }: AuditCardProps) => {
  const auditDate = new Date(audit.scheduledDate);
  const isUpcoming = isFuture(auditDate);
  const isOngoing = isToday(auditDate);
  const isPastDue = isPast(auditDate) && audit.status !== "Completed";
  
  // Determine card styling based on status
  let cardClass = "border";
  if (isOngoing) cardClass += " border-primary bg-primary/5";
  else if (isPastDue) cardClass += " border-destructive bg-destructive/5";
  else if (isUpcoming) cardClass += " border-secondary bg-secondary/5";
  
  return (
    <Card className={cardClass}>
      <CardContent className="pt-6">
        <div className="flex items-start justify-between mb-2">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              {audit.auditType === "Internal" ? (
                <ClipboardIcon className="w-4 h-4 text-primary" />
              ) : (
                <ClipboardCheckIcon className="w-4 h-4 text-secondary" />
              )}
              <span className="text-sm text-muted-foreground">{audit.auditType} Audit</span>
            </div>
            <h3 className="font-medium text-base">{audit.title}</h3>
          </div>
          <StatusBadge status={audit.status} />
        </div>
        
        <div className="text-sm text-muted-foreground mb-4">
          {audit.description}
        </div>
        
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <div className="text-muted-foreground mb-1">Date</div>
            <div className="flex items-center gap-1.5">
              <CalendarIcon className="w-3.5 h-3.5 text-muted-foreground" />
              {format(auditDate, 'MMM d, yyyy')}
            </div>
          </div>
          <div>
            <div className="text-muted-foreground mb-1">Location</div>
            <div>{audit.location}</div>
          </div>
          <div>
            <div className="text-muted-foreground mb-1">Auditor</div>
            <div>{audit.auditor}</div>
          </div>
          <div>
            {audit.completedDate && (
              <>
                <div className="text-muted-foreground mb-1">Completed</div>
                <div>{format(new Date(audit.completedDate), 'MMM d, yyyy')}</div>
              </>
            )}
          </div>
        </div>
        
        <div className="mt-4 flex justify-end">
          <Button variant="outline" size="sm">View Details</Button>
        </div>
      </CardContent>
    </Card>
  );
};

const LoadingSkeleton = () => (
  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
    {[...Array(4)].map((_, i) => (
      <Card key={i} className="border">
        <CardContent className="pt-6">
          <div className="flex items-start justify-between mb-2">
            <div className="flex-1">
              <Skeleton className="h-4 w-24 mb-2" />
              <Skeleton className="h-5 w-48" />
            </div>
            <Skeleton className="h-5 w-20 rounded-full" />
          </div>
          
          <Skeleton className="h-4 w-full mb-4" />
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Skeleton className="h-3 w-12 mb-1" />
              <Skeleton className="h-4 w-24" />
            </div>
            <div>
              <Skeleton className="h-3 w-12 mb-1" />
              <Skeleton className="h-4 w-24" />
            </div>
            <div>
              <Skeleton className="h-3 w-12 mb-1" />
              <Skeleton className="h-4 w-24" />
            </div>
            <div>
              <Skeleton className="h-3 w-12 mb-1" />
              <Skeleton className="h-4 w-24" />
            </div>
          </div>
          
          <div className="mt-4 flex justify-end">
            <Skeleton className="h-9 w-24" />
          </div>
        </CardContent>
      </Card>
    ))}
  </div>
);

const AuditSchedule = () => {
  const [filterStatus, setFilterStatus] = useState<string | null>(null);
  
  const { data: audits, isLoading } = useQuery<Audit[]>({
    queryKey: ['/api/audits'],
  });
  
  // Filter audits based on status if a filter is applied
  const filteredAudits = audits?.filter(audit => {
    if (!filterStatus) return true;
    return audit.status === filterStatus;
  }) || [];
  
  // Sort by scheduled date (upcoming first)
  const sortedAudits = [...filteredAudits].sort((a, b) => 
    new Date(a.scheduledDate).getTime() - new Date(b.scheduledDate).getTime()
  );
  
  // Count of audits by status
  const scheduledCount = audits?.filter(a => a.status === "Scheduled").length || 0;
  const inProgressCount = audits?.filter(a => a.status === "In Progress").length || 0;
  const completedCount = audits?.filter(a => a.status === "Completed").length || 0;
  
  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <CardTitle>Audit Schedule</CardTitle>
            <CardDescription>
              View upcoming and past audits
            </CardDescription>
          </div>
          <Button>
            <PlusIcon className="w-4 h-4 mr-2" />
            Schedule Audit
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-3 mb-6">
          <Button 
            variant={!filterStatus ? "default" : "outline"} 
            size="sm"
            onClick={() => setFilterStatus(null)}
          >
            All ({audits?.length || 0})
          </Button>
          <Button 
            variant={filterStatus === "Scheduled" ? "default" : "outline"} 
            size="sm"
            onClick={() => setFilterStatus("Scheduled")}
          >
            Scheduled ({scheduledCount})
          </Button>
          <Button 
            variant={filterStatus === "In Progress" ? "default" : "outline"} 
            size="sm"
            onClick={() => setFilterStatus("In Progress")}
          >
            In Progress ({inProgressCount})
          </Button>
          <Button 
            variant={filterStatus === "Completed" ? "default" : "outline"} 
            size="sm"
            onClick={() => setFilterStatus("Completed")}
          >
            Completed ({completedCount})
          </Button>
        </div>
        
        {isLoading ? (
          <LoadingSkeleton />
        ) : sortedAudits.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {sortedAudits.map(audit => (
              <AuditCard key={audit.id} audit={audit} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-muted-foreground">
            {filterStatus 
              ? `No ${filterStatus.toLowerCase()} audits found` 
              : "No audits scheduled yet"}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AuditSchedule;
