import { useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface HeaderProps {
  onMobileMenuToggle: () => void;
}

export default function Header({ onMobileMenuToggle }: HeaderProps) {
  const [location] = useLocation();
  
  const getPageTitle = () => {
    switch (true) {
      case location === "/":
        return "Dashboard";
      case location === "/report-incident":
        return "Report Incident";
      case location.startsWith("/incidents"):
        return "Incident Management";
      case location.startsWith("/documents"):
        return "Documents";
      case location.startsWith("/compliance"):
        return "Compliance";
      case location.startsWith("/risk-assessment"):
        return "Risk Assessment";
      default:
        return "Dashboard";
    }
  };
  
  return (
    <>
      {/* Mobile header */}
      <div className="md:hidden fixed top-0 left-0 right-0 bg-white border-b border-gray-200 z-10">
        <div className="flex items-center justify-between px-4 h-16">
          <h1 className="text-xl font-bold text-primary">EHS Manager</h1>
          <button 
            onClick={onMobileMenuToggle}
            className="p-2 rounded-md text-gray-700 hover:bg-gray-100"
          >
            <i className="ri-menu-line text-2xl"></i>
          </button>
        </div>
      </div>

      {/* Desktop header */}
      <header className="hidden md:flex h-16 bg-white border-b border-gray-200 items-center justify-between px-6">
        <div className="flex items-center">
          <h2 className="text-lg font-semibold">{getPageTitle()}</h2>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Input 
              type="text" 
              placeholder="Search..." 
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary/50" 
            />
            <i className="ri-search-line absolute left-3 top-2.5 text-gray-400"></i>
          </div>
          
          <Button variant="ghost" size="icon" className="rounded-full bg-gray-100 text-gray-700 hover:bg-gray-200">
            <i className="ri-notification-3-line text-lg"></i>
          </Button>
          
          <Button variant="ghost" size="icon" className="rounded-full bg-gray-100 text-gray-700 hover:bg-gray-200">
            <i className="ri-settings-3-line text-lg"></i>
          </Button>
        </div>
      </header>
    </>
  );
}
