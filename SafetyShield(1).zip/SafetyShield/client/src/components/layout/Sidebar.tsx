import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

interface NavItemProps {
  href: string;
  icon: string;
  children: React.ReactNode;
  active?: boolean;
}

const NavItem = ({ href, icon, children, active = false }: NavItemProps) => (
  <Link href={href}>
    <a className={cn(
      "flex items-center px-4 py-2 mt-1 text-sm font-medium rounded-md",
      active 
        ? "bg-primary text-white" 
        : "text-[#2C3E50] hover:bg-[#F5F7FA] hover:text-primary"
    )}>
      <i className={`${icon} mr-3 text-lg`}></i>
      {children}
    </a>
  </Link>
);

const NavSection = ({ title, children }: { title: string, children: React.ReactNode }) => (
  <div className="mb-3">
    <p className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
      {title}
    </p>
    {children}
  </div>
);

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="hidden md:flex md:flex-col w-64 bg-white border-r border-gray-200 h-full">
      <div className="flex items-center justify-center h-16 border-b border-gray-200">
        <h1 className="text-xl font-bold text-primary">EHS Manager</h1>
      </div>
      
      <div className="overflow-y-auto sidebar-scrollbar flex-grow">
        <nav className="mt-5 px-2">
          <div className="mb-3">
            <NavItem href="/" icon="ri-dashboard-line" active={location === "/"}>
              Dashboard
            </NavItem>
          </div>
          
          <NavSection title="Incident Management">
            <NavItem href="/report-incident" icon="ri-alarm-warning-line" active={location === "/report-incident"}>
              Report Incident
            </NavItem>
            <NavItem href="/incidents" icon="ri-file-list-3-line" active={location === "/incidents"}>
              Incident Tracking
            </NavItem>
            <NavItem href="/incidents?tab=investigations" icon="ri-search-line" active={location === "/incidents?tab=investigations"}>
              Investigations
            </NavItem>
          </NavSection>
          
          <NavSection title="Documentation">
            <NavItem href="/documents" icon="ri-folder-line" active={location === "/documents"}>
              Documents
            </NavItem>
            <NavItem href="/documents?type=policy" icon="ri-file-text-line" active={location === "/documents?type=policy"}>
              Policies
            </NavItem>
          </NavSection>
          
          <NavSection title="Compliance">
            <NavItem href="/compliance" icon="ri-checkbox-line" active={location === "/compliance"}>
              Compliance Status
            </NavItem>
            <NavItem href="/compliance?tab=deadlines" icon="ri-calendar-check-line" active={location === "/compliance?tab=deadlines"}>
              Deadlines
            </NavItem>
            <NavItem href="/compliance?tab=audits" icon="ri-file-search-line" active={location === "/compliance?tab=audits"}>
              Audits
            </NavItem>
          </NavSection>
          
          <NavSection title="Risk Management">
            <NavItem href="/risk-assessment?tab=hazards" icon="ri-error-warning-line" active={location === "/risk-assessment?tab=hazards"}>
              Hazard Identification
            </NavItem>
            <NavItem href="/risk-assessment" icon="ri-bar-chart-box-line" active={location === "/risk-assessment"}>
              Risk Assessment
            </NavItem>
            <NavItem href="/risk-assessment?tab=actions" icon="ri-list-check" active={location === "/risk-assessment?tab=actions"}>
              Action Items
            </NavItem>
          </NavSection>
        </nav>
      </div>
      
      <div className="border-t border-gray-200 p-4">
        <a href="#" className="flex items-center text-sm font-medium text-[#2C3E50]">
          <div className="h-8 w-8 rounded-full bg-gray-300 flex items-center justify-center mr-2">
            <span className="text-sm font-medium text-gray-700">JD</span>
          </div>
          <div>
            <p className="font-medium">John Doe</p>
            <p className="text-xs text-gray-500">Safety Manager</p>
          </div>
        </a>
      </div>
    </aside>
  );
}
