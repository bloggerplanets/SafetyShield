import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  HomeIcon, 
  ClipboardIcon, 
  FileTextIcon, 
  GanttChartIcon, 
  AlertTriangleIcon, 
  CalendarIcon, 
  BarChart3Icon,
  Settings,
  ChevronDownIcon,
  GraduationCapIcon,
  UserIcon,
  XIcon
} from "lucide-react";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

interface NavItemProps {
  href: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  active?: boolean;
  onClick: () => void;
}

const NavItem = ({ href, icon, children, active = false, onClick }: NavItemProps) => (
  <Link href={href}>
    <div 
      className={cn(
        "flex items-center px-4 py-2 mt-1 text-sm font-medium rounded-md cursor-pointer",
        active 
          ? "bg-primary text-white" 
          : "text-[#2C3E50] hover:bg-[#F5F7FA] hover:text-primary"
      )}
      onClick={onClick}
    >
      <span className="mr-3">{icon}</span>
      {children}
    </div>
  </Link>
);

const NavSection = ({ title, children }: { title: string, children: React.ReactNode }) => (
  <div className="mb-3">
    <p className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
      {title}
    </p>
    {children}
  </div>
);

export default function MobileMenu({ isOpen, onClose }: MobileMenuProps) {
  const [location] = useLocation();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-40 bg-black bg-opacity-50">
      <div className="absolute top-0 left-0 bottom-0 w-64 bg-white">
        <div className="flex justify-between items-center p-4 border-b border-gray-200">
          <h2 className="font-bold text-primary">EHS Management</h2>
          <button onClick={onClose} className="p-2">
            <XIcon className="w-5 h-5" />
          </button>
        </div>
        
        <div className="overflow-y-auto h-full pb-20">
          <nav className="mt-5 px-2 space-y-1">
            <NavItem 
              href="/" 
              icon={<HomeIcon className="w-5 h-5" />} 
              active={location === "/"} 
              onClick={onClose}
            >
              Dashboard
            </NavItem>
            
            <NavSection title="Incidents">
              <NavItem 
                href="/incidents/report" 
                icon={<ClipboardIcon className="w-5 h-5" />} 
                active={location === "/incidents/report"} 
                onClick={onClose}
              >
                Report Incident
              </NavItem>
              <NavItem 
                href="/incidents" 
                icon={<ClipboardIcon className="w-5 h-5" />} 
                active={location === "/incidents"} 
                onClick={onClose}
              >
                Incident Dashboard
              </NavItem>
            </NavSection>
            
            <NavItem 
              href="/documents" 
              icon={<FileTextIcon className="w-5 h-5" />} 
              active={location === "/documents"} 
              onClick={onClose}
            >
              Documents
            </NavItem>
            
            <NavItem 
              href="/compliance" 
              icon={<GanttChartIcon className="w-5 h-5" />} 
              active={location === "/compliance"} 
              onClick={onClose}
            >
              Compliance
            </NavItem>
            
            <NavItem 
              href="/risk" 
              icon={<AlertTriangleIcon className="w-5 h-5" />} 
              active={location === "/risk"} 
              onClick={onClose}
            >
              Risk Assessment
            </NavItem>
            
            <NavItem 
              href="/audits" 
              icon={<CalendarIcon className="w-5 h-5" />} 
              active={location === "/audits"} 
              onClick={onClose}
            >
              Audits
            </NavItem>
            
            <NavItem 
              href="/reports" 
              icon={<BarChart3Icon className="w-5 h-5" />} 
              active={location === "/reports"} 
              onClick={onClose}
            >
              Reports
            </NavItem>
            
            <NavItem 
              href="/courses" 
              icon={<GraduationCapIcon className="w-5 h-5" />} 
              active={location === "/courses"} 
              onClick={onClose}
            >
              Training & Courses
            </NavItem>
            
            <NavItem 
              href="/calendar" 
              icon={<CalendarIcon className="w-5 h-5" />} 
              active={location === "/calendar"} 
              onClick={onClose}
            >
              Calendar
            </NavItem>
            
            <NavItem 
              href="/login" 
              icon={<UserIcon className="w-5 h-5" />} 
              active={location === "/login"} 
              onClick={onClose}
            >
              Login
            </NavItem>
            
            <NavItem 
              href="/settings" 
              icon={<Settings className="w-5 h-5" />} 
              active={location === "/settings"} 
              onClick={onClose}
            >
              Settings
            </NavItem>
          </nav>
        </div>
      </div>
    </div>
  );
}
