import IncidentForm from "@/components/incidents/IncidentForm";

const ReportIncidentPage = () => {
  return (
    <div className="space-y-6">
      <IncidentForm />
      
      {/* Bottom spacing */}
      <div className="h-16"></div>
    </div>
  );
};

export default ReportIncidentPage;
