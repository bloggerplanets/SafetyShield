import IncidentList from "@/components/incidents/IncidentList";

const IncidentsPage = () => {
  return (
    <div className="space-y-6">
      <IncidentList />
      
      {/* Bottom spacing */}
      <div className="h-16"></div>
    </div>
  );
};

export default IncidentsPage;
