import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { InsertComplianceItem, insertComplianceItemSchema } from "@shared/schema";
import { useMutation, queryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface StatusBadgeProps {
  status: string;
}

const StatusBadge = ({ status }: StatusBadgeProps) => {
  const statusStyles = {
    "compliant": "bg-green-100 text-[#27AE60]",
    "review-needed": "bg-yellow-100 text-yellow-600",
    "non-compliant": "bg-red-100 text-[#E74C3C]"
  };
  
  const statusKey = status.toLowerCase().replace(' ', '-') as keyof typeof statusStyles;
  const style = statusStyles[statusKey] || "bg-gray-100 text-gray-600";
  
  return (
    <span className={`px-2 py-1 text-xs font-medium ${style} rounded-full`}>
      {status === "review-needed" ? "Review Needed" : status}
    </span>
  );
};

// Add compliance item form schema
const formSchema = insertComplianceItemSchema.extend({
  title: z.string().min(3, "Title must be at least 3 characters"),
  description: z.string().min(5, "Description must be at least 5 characters"),
  category: z.string().min(2, "Category is required"),
  progress: z.coerce.number().min(0).max(100),
  status: z.string(),
  dueDate: z.string().optional(),
  responsiblePerson: z.coerce.number()
});

export default function Compliance() {
  const [location] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const { toast } = useToast();
  
  // Determine which tab to show
  const currentTab = location.includes("tab=deadlines") 
    ? "deadlines" 
    : location.includes("tab=audits") 
      ? "audits" 
      : "status";
  
  // Fetch compliance items data
  const { data: complianceItems, isLoading: complianceLoading } = useQuery({
    queryKey: ['/api/compliance'],
  });
  
  // Fetch deadlines data
  const { data: deadlines, isLoading: deadlinesLoading } = useQuery({
    queryKey: ['/api/deadlines'],
  });
  
  // Form setup
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      category: "",
      progress: 0,
      status: "non-compliant",
      responsiblePerson: 1, // Default to current user
    },
  });
  
  // Create compliance item mutation
  const mutation = useMutation({
    mutationFn: async (values: InsertComplianceItem) => {
      const res = await apiRequest("POST", "/api/compliance", values);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Compliance Item Added",
        description: "The compliance item has been successfully added",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/compliance'] });
      setIsAddDialogOpen(false);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add compliance item: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  function onSubmit(values: z.infer<typeof formSchema>) {
    mutation.mutate(values);
  }
  
  // Filter compliance items based on search term
  const filteredComplianceItems = complianceItems
    ? complianceItems.filter((item: any) => 
        !searchTerm || 
        item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.category.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : [];
    
  // Sort deadlines by due date
  const sortedDeadlines = deadlines
    ? [...deadlines].sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
    : [];

  return (
    <Card className="shadow">
      <CardHeader className="pb-3">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <CardTitle className="text-2xl font-bold text-[#2C3E50]">Compliance Management</CardTitle>
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search..."
                className="pl-10 w-full sm:w-64"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <i className="ri-search-line absolute left-3 top-2.5 text-gray-400"></i>
            </div>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-primary hover:bg-primary/90 text-white">
                  <i className="ri-add-line mr-1"></i> Add Item
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[550px]">
                <DialogHeader>
                  <DialogTitle>Add Compliance Item</DialogTitle>
                  <DialogDescription>
                    Add a new compliance requirement or standard to track.
                  </DialogDescription>
                </DialogHeader>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Title</FormLabel>
                            <FormControl>
                              <Input placeholder="Compliance title" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Category</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. Regulatory, Documentation" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Detailed description of the compliance requirement" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="status"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Status</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select status" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="compliant">Compliant</SelectItem>
                                <SelectItem value="non-compliant">Non-Compliant</SelectItem>
                                <SelectItem value="review-needed">Review Needed</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="progress"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Progress (%)</FormLabel>
                            <FormControl>
                              <Input type="number" min="0" max="100" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="dueDate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Due Date (Optional)</FormLabel>
                            <FormControl>
                              <Input type="date" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="responsiblePerson"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Responsible Person</FormLabel>
                            <FormControl>
                              <Input type="number" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <DialogFooter>
                      <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button 
                        type="submit" 
                        className="bg-primary hover:bg-primary/90 text-white"
                        disabled={mutation.isPending}
                      >
                        {mutation.isPending ? "Adding..." : "Add Compliance Item"}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue={currentTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="status">Compliance Status</TabsTrigger>
            <TabsTrigger value="deadlines">Deadlines</TabsTrigger>
            <TabsTrigger value="audits">Audits</TabsTrigger>
          </TabsList>
          
          <TabsContent value="status" className="mt-0">
            {complianceLoading ? (
              <div className="space-y-4">
                {Array(4).fill(0).map((_, i) => (
                  <div key={i} className="border border-gray-200 rounded-md p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <Skeleton className="h-5 w-40 mb-2" />
                        <Skeleton className="h-4 w-64" />
                      </div>
                      <Skeleton className="h-6 w-20 rounded-full" />
                    </div>
                    <div className="mt-3">
                      <div className="flex justify-between text-sm mb-1">
                        <span>Progress</span>
                        <Skeleton className="h-4 w-8" />
                      </div>
                      <Skeleton className="h-2 w-full rounded-full" />
                    </div>
                    <div className="mt-3">
                      <Skeleton className="h-4 w-32" />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {filteredComplianceItems.length === 0 ? (
                  <div className="text-center py-12 text-gray-500">
                    No compliance items found
                  </div>
                ) : (
                  filteredComplianceItems.map((item: any) => (
                    <div key={item.id} className="border border-gray-200 rounded-md p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-medium text-[#2C3E50]">{item.title}</h3>
                          <p className="text-sm text-gray-500 mt-1">{item.description}</p>
                          <p className="text-xs text-gray-500 mt-1">Category: {item.category}</p>
                        </div>
                        <StatusBadge status={item.status} />
                      </div>
                      <div className="mt-3">
                        <div className="flex justify-between text-sm mb-1">
                          <span>Progress</span>
                          <span className="font-medium">{item.progress}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-primary rounded-full h-2" 
                            style={{ width: `${item.progress}%` }}
                          ></div>
                        </div>
                      </div>
                      <div className="mt-3 flex justify-between items-center">
                        <span className="text-xs text-gray-500">
                          Last updated: {new Date(item.lastUpdated).toLocaleDateString('en-US', { 
                            year: 'numeric', 
                            month: 'long', 
                            day: 'numeric' 
                          })}
                        </span>
                        <div className="flex space-x-2">
                          <Button variant="ghost" size="sm" className="h-8 px-2 text-gray-500 hover:text-primary">
                            <i className="ri-eye-line"></i>
                          </Button>
                          <Button variant="ghost" size="sm" className="h-8 px-2 text-gray-500 hover:text-primary">
                            <i className="ri-edit-line"></i>
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="deadlines" className="mt-0">
            {deadlinesLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-8 w-full" />
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Description</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Responsible</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sortedDeadlines.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                          No deadlines found
                        </TableCell>
                      </TableRow>
                    ) : (
                      sortedDeadlines.map((deadline: any) => {
                        const dueDate = new Date(deadline.dueDate);
                        const isUrgent = dueDate.getTime() - new Date().getTime() < 7 * 24 * 60 * 60 * 1000; // less than 7 days
                        
                        return (
                          <TableRow key={deadline.id}>
                            <TableCell className="font-medium">{deadline.description}</TableCell>
                            <TableCell>
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                deadline.type === 'Training' 
                                  ? 'bg-blue-100 text-primary' 
                                  : deadline.type === 'Regulatory' 
                                    ? 'bg-red-100 text-[#E74C3C]' 
                                    : deadline.type === 'Exercise'
                                      ? 'bg-purple-100 text-purple-600'
                                      : deadline.type === 'Inspection'
                                        ? 'bg-green-100 text-[#27AE60]'
                                        : 'bg-orange-100 text-orange-600'
                              }`}>
                                {deadline.type}
                              </span>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <i className={`ri-calendar-check-line ${isUrgent ? 'text-[#E74C3C]' : 'text-gray-500'} mr-2`}></i>
                                <span>{dueDate.toLocaleDateString('en-US', { 
                                  year: 'numeric', 
                                  month: 'long', 
                                  day: 'numeric' 
                                })}</span>
                              </div>
                            </TableCell>
                            <TableCell>{deadline.responsiblePerson}</TableCell>
                            <TableCell>
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                deadline.status === 'pending'
                                  ? 'bg-yellow-100 text-yellow-600'
                                  : deadline.status === 'in progress'
                                    ? 'bg-blue-100 text-primary'
                                    : deadline.status === 'completed'
                                      ? 'bg-green-100 text-[#27AE60]'
                                      : 'bg-gray-100 text-gray-600'
                              }`}>
                                {deadline.status.charAt(0).toUpperCase() + deadline.status.slice(1)}
                              </span>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex space-x-2 justify-end">
                                <Button variant="ghost" size="sm" className="p-1 text-gray-500 hover:text-primary">
                                  <i className="ri-eye-line"></i>
                                </Button>
                                <Button variant="ghost" size="sm" className="p-1 text-gray-500 hover:text-primary">
                                  <i className="ri-edit-line"></i>
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="audits" className="mt-0">
            <div className="bg-white rounded-lg p-6 border border-gray-200">
              <div className="text-center mb-6">
                <h3 className="text-lg font-medium text-[#2C3E50]">Upcoming Audits</h3>
                <p className="text-sm text-gray-500 mt-1">Schedule and track audit activities</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="border-2 border-primary/20">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-medium">Internal Safety Audit</h4>
                      <span className="px-2 py-0.5 text-xs bg-blue-100 text-primary rounded-full">Scheduled</span>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">Comprehensive review of all safety procedures and documentation</p>
                    <div className="flex items-center text-sm text-gray-500">
                      <i className="ri-calendar-line mr-1"></i>
                      <span>August 15, 2023</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-500 mt-1">
                      <i className="ri-user-line mr-1"></i>
                      <span>Lead: Sarah Johnson</span>
                    </div>
                    <Button className="w-full mt-4 bg-white text-primary border border-primary hover:bg-primary/5">
                      View Details
                    </Button>
                  </CardContent>
                </Card>
                
                <Card className="border-2 border-[#27AE60]/20">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-medium">OSHA Compliance Audit</h4>
                      <span className="px-2 py-0.5 text-xs bg-yellow-100 text-yellow-600 rounded-full">Preparation</span>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">Verify compliance with OSHA standards and regulations</p>
                    <div className="flex items-center text-sm text-gray-500">
                      <i className="ri-calendar-line mr-1"></i>
                      <span>September 10, 2023</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-500 mt-1">
                      <i className="ri-user-line mr-1"></i>
                      <span>Lead: Robert Miller</span>
                    </div>
                    <Button className="w-full mt-4 bg-white text-[#27AE60] border border-[#27AE60] hover:bg-[#27AE60]/5">
                      View Details
                    </Button>
                  </CardContent>
                </Card>
                
                <Card className="border border-gray-200">
                  <CardContent className="p-4 flex flex-col items-center justify-center h-full">
                    <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center mb-3">
                      <i className="ri-add-line text-xl text-gray-500"></i>
                    </div>
                    <p className="text-sm text-gray-500 mb-4 text-center">Schedule a new audit or assessment</p>
                    <Button variant="outline">Schedule Audit</Button>
                  </CardContent>
                </Card>
              </div>
              
              <div className="mt-8">
                <h3 className="text-lg font-medium text-[#2C3E50] mb-4">Previous Audits</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Audit Name</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Score</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">Fire Safety Audit</TableCell>
                      <TableCell>
                        <span className="px-2 py-0.5 text-xs bg-red-100 text-[#E74C3C] rounded-full">
                          External
                        </span>
                      </TableCell>
                      <TableCell>June 12, 2023</TableCell>
                      <TableCell>
                        <span className="px-2 py-0.5 text-xs bg-green-100 text-[#27AE60] rounded-full">
                          Completed
                        </span>
                      </TableCell>
                      <TableCell>92%</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" className="p-1 text-gray-500 hover:text-primary">
                          <i className="ri-file-list-line"></i>
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">PPE Compliance Audit</TableCell>
                      <TableCell>
                        <span className="px-2 py-0.5 text-xs bg-blue-100 text-primary rounded-full">
                          Internal
                        </span>
                      </TableCell>
                      <TableCell>May 20, 2023</TableCell>
                      <TableCell>
                        <span className="px-2 py-0.5 text-xs bg-green-100 text-[#27AE60] rounded-full">
                          Completed
                        </span>
                      </TableCell>
                      <TableCell>85%</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" className="p-1 text-gray-500 hover:text-primary">
                          <i className="ri-file-list-line"></i>
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Chemical Storage Audit</TableCell>
                      <TableCell>
                        <span className="px-2 py-0.5 text-xs bg-purple-100 text-purple-600 rounded-full">
                          Regulatory
                        </span>
                      </TableCell>
                      <TableCell>April 5, 2023</TableCell>
                      <TableCell>
                        <span className="px-2 py-0.5 text-xs bg-yellow-100 text-yellow-600 rounded-full">
                          Actions Required
                        </span>
                      </TableCell>
                      <TableCell>78%</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" className="p-1 text-gray-500 hover:text-primary">
                          <i className="ri-file-list-line"></i>
                        </Button>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
