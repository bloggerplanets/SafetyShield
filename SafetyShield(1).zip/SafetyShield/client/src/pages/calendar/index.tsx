import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CalendarIcon, PlusIcon, FilterIcon, ArrowLeftIcon, ArrowRightIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function CalendarPage() {
  const today = new Date();
  const month = today.toLocaleString('default', { month: 'long' });
  const year = today.getFullYear();

  // Generate calendar days (simplified version)
  const daysInMonth = new Date(year, today.getMonth() + 1, 0).getDate();
  const firstDayOfMonth = new Date(year, today.getMonth(), 1).getDay();
  
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const fillerDaysBefore = Array.from({ length: firstDayOfMonth }, (_, i) => null);
  
  // Sample events
  const events = [
    {
      id: 1,
      title: "Annual Fire Safety Training",
      start: 5,
      type: "training",
      location: "Training Room A"
    },
    {
      id: 2,
      title: "Quarterly Safety Committee Meeting",
      start: 12,
      type: "meeting",
      location: "Conference Room 2"
    },
    {
      id: 3,
      title: "OSHA Audit Preparation",
      start: 18,
      type: "audit",
      location: "Main Office"
    },
    {
      id: 4,
      title: "Emergency Response Drill",
      start: 25,
      type: "drill",
      location: "All Facilities"
    }
  ];
  
  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Calendar</h1>
          <p className="text-gray-500 mt-1">Manage and view upcoming events</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="flex items-center gap-2">
            <FilterIcon className="h-4 w-4" />
            Filter
          </Button>
          <Button className="flex items-center gap-2">
            <PlusIcon className="h-4 w-4" />
            Add Event
          </Button>
        </div>
      </div>
      
      <Tabs defaultValue="month">
        <TabsList>
          <TabsTrigger value="month">Month</TabsTrigger>
          <TabsTrigger value="week">Week</TabsTrigger>
          <TabsTrigger value="day">Day</TabsTrigger>
          <TabsTrigger value="agenda">Agenda</TabsTrigger>
        </TabsList>
        
        <TabsContent value="month" className="mt-6">
          <Card>
            <CardContent className="p-0">
              <div className="flex justify-between items-center p-4 border-b">
                <Button variant="ghost" size="sm">
                  <ArrowLeftIcon className="h-4 w-4 mr-2" />
                  Previous
                </Button>
                <h2 className="text-xl font-semibold">{month} {year}</h2>
                <Button variant="ghost" size="sm">
                  Next
                  <ArrowRightIcon className="h-4 w-4 ml-2" />
                </Button>
              </div>
              
              <div className="grid grid-cols-7 border-b">
                {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                  <div key={day} className="p-2 text-center font-medium text-sm">
                    {day}
                  </div>
                ))}
              </div>
              
              <div className="grid grid-cols-7">
                {[...fillerDaysBefore, ...days].map((day, i) => (
                  <div 
                    key={i} 
                    className={`min-h-[100px] p-2 border-r border-b relative ${
                      day === today.getDate() ? "bg-primary/5" : ""
                    } ${day === null ? "bg-gray-50" : ""}`}
                  >
                    {day !== null && (
                      <>
                        <div className={`text-sm mb-1 ${day === today.getDate() ? "font-bold" : ""}`}>
                          {day}
                        </div>
                        
                        {events
                          .filter(event => event.start === day)
                          .map(event => (
                            <div 
                              key={event.id} 
                              className={`p-1 mb-1 text-xs rounded-md ${
                                event.type === "training" ? "bg-blue-100 text-blue-800" :
                                event.type === "meeting" ? "bg-green-100 text-green-800" :
                                event.type === "audit" ? "bg-orange-100 text-orange-800" : 
                                "bg-red-100 text-red-800"
                              }`}
                            >
                              {event.title}
                            </div>
                          ))
                        }
                      </>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="week" className="mt-6">
          <Card>
            <CardContent className="py-6">
              <p className="text-center text-gray-500">Week view coming soon</p>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="day" className="mt-6">
          <Card>
            <CardContent className="py-6">
              <p className="text-center text-gray-500">Day view coming soon</p>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="agenda" className="mt-6">
          <Card>
            <CardContent className="py-6">
              <p className="text-center text-gray-500">Agenda view coming soon</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}