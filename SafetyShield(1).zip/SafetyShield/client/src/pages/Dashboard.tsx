import WelcomeCard from "@/components/dashboard/WelcomeCard";
import MetricsOverview from "@/components/dashboard/MetricsOverview";
import ComplianceStatus from "@/components/dashboard/ComplianceStatus";
import RecentIncidents from "@/components/dashboard/RecentIncidents";
import UpcomingDeadlines from "@/components/dashboard/UpcomingDeadlines";
import RiskMatrix from "@/components/dashboard/RiskMatrix";

export default function Dashboard() {
  return (
    <>
      <WelcomeCard />
      <MetricsOverview />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <ComplianceStatus />
        <RecentIncidents />
      </div>
      
      <UpcomingDeadlines />
      <RiskMatrix />
    </>
  );
}
