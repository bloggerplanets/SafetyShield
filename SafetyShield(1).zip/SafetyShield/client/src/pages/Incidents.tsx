import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle
} from "@/components/ui/alert-dialog";
import { PlusIcon, SearchIcon, Trash2Icon, PencilIcon, EyeIcon } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface StatusBadgeProps {
  status: string;
}

const StatusBadge = ({ status }: StatusBadgeProps) => {
  const statusStyles = {
    "open": "bg-yellow-100 text-yellow-600",
    "investigating": "bg-blue-100 text-primary",
    "resolved": "bg-green-100 text-[#27AE60]"
  };
  
  const statusKey = status.toLowerCase() as keyof typeof statusStyles;
  const style = statusStyles[statusKey] || "bg-gray-100 text-gray-600";
  
  return (
    <span className={`px-2 py-0.5 text-xs ${style} rounded-full`}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
};

interface SeverityBadgeProps {
  severity: string;
}

const SeverityBadge = ({ severity }: SeverityBadgeProps) => {
  const severityStyles = {
    "high": "bg-red-100 text-[#E74C3C]",
    "medium": "bg-yellow-100 text-yellow-600",
    "low": "bg-blue-100 text-primary"
  };
  
  const severityKey = severity.toLowerCase() as keyof typeof severityStyles;
  const style = severityStyles[severityKey] || "bg-gray-100 text-gray-600";
  
  return (
    <span className={`px-2 py-0.5 text-xs ${style} rounded-full`}>
      {severity.charAt(0).toUpperCase() + severity.slice(1)}
    </span>
  );
};

export default function Incidents() {
  const [location, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedIncident, setSelectedIncident] = useState<any>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Determine which tab to show
  const currentTab = location.includes("investigations") ? "investigations" : "all";
  
  // Fetch incidents data
  const { data: incidents, isLoading } = useQuery({
    queryKey: ['/api/incidents'],
  });
  
  // Delete incident mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/incidents/${id}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/incidents'] });
      toast({
        title: "Incident deleted",
        description: "The incident has been successfully deleted.",
      });
      setIsDeleteDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete incident: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const handleDeleteIncident = (incident: any) => {
    setSelectedIncident(incident);
    setIsDeleteDialogOpen(true);
  };
  
  const confirmDelete = () => {
    if (selectedIncident) {
      deleteMutation.mutate(selectedIncident.id);
    }
  };
  
  const filteredIncidents = incidents
    ? incidents.filter((incident: any) => {
        // Search filter
        const matchesSearch = !searchTerm || 
          incident.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          incident.location?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          incident.description?.toLowerCase().includes(searchTerm.toLowerCase());
          
        // Tab filter
        const matchesTab = currentTab === "all" || 
          (currentTab === "investigations" && incident.status === "investigating");
          
        return matchesSearch && matchesTab;
      })
    : [];

  return (
    <>
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the incident
              "{selectedIncident?.title}" and remove all related data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    
      <Card className="shadow">
        <CardHeader className="pb-3">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <CardTitle className="text-2xl font-bold text-[#2C3E50]">Incident Management</CardTitle>
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Search incidents..."
                  className="pl-10 w-full sm:w-64"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <SearchIcon className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
              </div>
              <Link href="/incidents/report">
                <Button className="bg-primary hover:bg-primary/90 text-white">
                  <PlusIcon className="w-4 h-4 mr-1" /> New Incident
                </Button>
              </Link>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue={currentTab} onValueChange={(value) => {
            value === "investigations" 
              ? setLocation("/incidents?tab=investigations") 
              : setLocation("/incidents");
          }}>
            <TabsList className="mb-4">
              <TabsTrigger value="all">All Incidents</TabsTrigger>
              <TabsTrigger value="investigations">Investigations</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all" className="mt-0">
              {isLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-8 w-full" />
                  <Skeleton className="h-20 w-full" />
                  <Skeleton className="h-20 w-full" />
                  <Skeleton className="h-20 w-full" />
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Title</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Location</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Severity</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredIncidents.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                            No incidents found
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredIncidents.map((incident: any) => (
                          <TableRow key={incident.id}>
                            <TableCell className="font-medium">{incident.title}</TableCell>
                            <TableCell className="capitalize">{incident.type}</TableCell>
                            <TableCell>{incident.location}</TableCell>
                            <TableCell>{new Date(incident.date).toLocaleDateString()}</TableCell>
                            <TableCell>
                              <SeverityBadge severity={incident.severity} />
                            </TableCell>
                            <TableCell>
                              <StatusBadge status={incident.status} />
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end space-x-1">
                                <Button variant="ghost" size="icon" title="View Details">
                                  <EyeIcon className="h-4 w-4" />
                                </Button>
                                <Link href={`/incidents/edit/${incident.id}`}>
                                  <Button variant="ghost" size="icon" title="Edit Incident">
                                    <PencilIcon className="h-4 w-4" />
                                  </Button>
                                </Link>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  title="Delete Incident"
                                  onClick={() => handleDeleteIncident(incident)}
                                >
                                  <Trash2Icon className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="investigations" className="mt-0">
              {isLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-8 w-full" />
                  <Skeleton className="h-20 w-full" />
                  <Skeleton className="h-20 w-full" />
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Incident</TableHead>
                        <TableHead>Location</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Assigned To</TableHead>
                        <TableHead>Progress</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredIncidents.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                            No active investigations found
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredIncidents.map((incident: any) => (
                          <TableRow key={incident.id}>
                            <TableCell className="font-medium">{incident.title}</TableCell>
                            <TableCell>{incident.location}</TableCell>
                            <TableCell>{new Date(incident.date).toLocaleDateString()}</TableCell>
                            <TableCell>{incident.assignedTo || 'Unassigned'}</TableCell>
                            <TableCell>
                              <div className="w-32 h-2 bg-gray-200 rounded-full">
                                <div className="bg-primary h-2 rounded-full" style={{ width: "40%" }}></div>
                              </div>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end space-x-1">
                                <Button variant="ghost" size="icon" title="View Details">
                                  <EyeIcon className="h-4 w-4" />
                                </Button>
                                <Link href={`/incidents/edit/${incident.id}`}>
                                  <Button variant="ghost" size="icon" title="Edit Incident">
                                    <PencilIcon className="h-4 w-4" />
                                  </Button>
                                </Link>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  title="Delete Incident"
                                  onClick={() => handleDeleteIncident(incident)}
                                >
                                  <Trash2Icon className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </>
  );
}