import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { RiskAssessment } from "@shared/schema";
import { format } from "date-fns";
import { 
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle 
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue 
} from "@/components/ui/select";
import { AlertTriangleIcon, FileTextIcon, PlusIcon, SearchIcon } from "lucide-react";
import RiskAssessmentForm from "@/components/risk/RiskAssessmentForm";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface RiskLevelBadgeProps {
  rating: number;
}

const RiskLevelBadge = ({ rating }: RiskLevelBadgeProps) => {
  let variant: "outline" | "default" | "secondary" | "destructive" = "outline";
  let label = "Low";
  
  if (rating >= 15) {
    variant = "destructive";
    label = "Critical";
  } else if (rating >= 10) {
    variant = "default";
    label = "High";
  } else if (rating >= 5) {
    variant = "secondary";
    label = "Medium";
  }
  
  return <Badge variant={variant}>{label}</Badge>;
};

const RiskAssessmentsList = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  
  const { data: riskAssessments, isLoading } = useQuery<RiskAssessment[]>({
    queryKey: ['/api/risk-assessments'],
  });
  
  // Filter assessments based on selected filters and search query
  const filteredAssessments = riskAssessments?.filter(assessment => {
    // Apply status filter
    if (statusFilter !== "all" && assessment.status !== statusFilter) {
      return false;
    }
    
    // Apply search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        assessment.title.toLowerCase().includes(query) ||
        assessment.description.toLowerCase().includes(query) ||
        assessment.location.toLowerCase().includes(query)
      );
    }
    
    return true;
  }) || [];
  
  // Sort assessments by assessment date (newest first)
  const sortedAssessments = [...filteredAssessments].sort((a, b) => 
    new Date(b.assessmentDate).getTime() - new Date(a.assessmentDate).getTime()
  );
  
  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <CardTitle>Risk Assessments</CardTitle>
            <CardDescription>
              View and manage all risk assessments
            </CardDescription>
          </div>
          <Link href="/risk?tab=new">
            <Button>
              <PlusIcon className="w-4 h-4 mr-2" />
              New Assessment
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-grow max-w-sm">
            <div className="relative">
              <SearchIcon className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Search assessments..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          <div className="flex flex-wrap gap-3">
            <Select defaultValue={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="Draft">Draft</SelectItem>
                <SelectItem value="Active">Active</SelectItem>
                <SelectItem value="Archived">Archived</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Title</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Assessment Date</TableHead>
                <TableHead>Risk Rating</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Review Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                [...Array(5)].map((_, i) => (
                  <TableRow key={i}>
                    <TableCell><Skeleton className="h-4 w-40" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-28" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-16 rounded-full" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-28" /></TableCell>
                  </TableRow>
                ))
              ) : sortedAssessments.length > 0 ? (
                sortedAssessments.map((assessment) => (
                  <TableRow key={assessment.id} className="hover:bg-muted/50">
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <FileTextIcon className="w-4 h-4 text-primary" />
                        {assessment.title}
                      </div>
                    </TableCell>
                    <TableCell>{assessment.location}</TableCell>
                    <TableCell>
                      {format(new Date(assessment.assessmentDate), 'MMM d, yyyy')}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{assessment.riskRating}</span>
                        <RiskLevelBadge rating={assessment.riskRating} />
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{assessment.status}</Badge>
                    </TableCell>
                    <TableCell>
                      {assessment.reviewDate 
                        ? format(new Date(assessment.reviewDate), 'MMM d, yyyy')
                        : "Not set"
                      }
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-6 text-gray-500">
                    {searchQuery || statusFilter !== 'all'
                      ? "No risk assessments match your filters"
                      : "No risk assessments have been created yet"}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

const RiskPage = () => {
  // Use URL parameters to switch tabs
  const [location, setLocation] = useState(window.location.search);
  const queryParams = new URLSearchParams(location);
  const tabFromUrl = queryParams.get('tab');
  
  const [activeTab, setActiveTab] = useState(tabFromUrl === 'new' ? 'new' : 'list');
  
  const handleTabChange = (value: string) => {
    setActiveTab(value);
    const newParams = new URLSearchParams(queryParams);
    
    if (value === 'new') {
      newParams.set('tab', 'new');
    } else {
      newParams.delete('tab');
    }
    
    const newUrl = `${window.location.pathname}${newParams.toString() ? `?${newParams.toString()}` : ''}`;
    window.history.pushState(null, '', newUrl);
    setLocation(newUrl);
  };
  
  return (
    <div className="space-y-6">
      {activeTab === 'new' ? (
        <>
          <div className="flex items-center">
            <Button 
              variant="ghost" 
              className="hover:bg-transparent p-0 mr-2"
              onClick={() => handleTabChange('list')}
            >
              ← Back to Assessments
            </Button>
            <AlertTriangleIcon className="h-5 w-5 text-yellow-500 mr-2" />
            <h1 className="text-xl font-semibold">New Risk Assessment</h1>
          </div>
          <RiskAssessmentForm />
        </>
      ) : (
        <Tabs 
          defaultValue="list" 
          value={activeTab} 
          onValueChange={handleTabChange}
          className="w-full"
        >
          <TabsList className="grid w-full md:w-[400px] grid-cols-2">
            <TabsTrigger value="list">Risk Assessments</TabsTrigger>
            <TabsTrigger value="new">Create New</TabsTrigger>
          </TabsList>
          <TabsContent value="list">
            <RiskAssessmentsList />
          </TabsContent>
          <TabsContent value="new">
            <RiskAssessmentForm />
          </TabsContent>
        </Tabs>
      )}
      
      {/* Bottom spacing */}
      <div className="h-16"></div>
    </div>
  );
};

export default RiskPage;
