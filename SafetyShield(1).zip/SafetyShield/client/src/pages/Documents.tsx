import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle
} from "@/components/ui/alert-dialog";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertDocumentSchema } from "@shared/schema";
import { Search, Upload, FileText, File, FilePlus, FileEdit, Trash2, Eye, Download, Calendar } from "lucide-react";

interface DocumentCardProps {
  id: number;
  title: string;
  type: string;
  category: string;
  description?: string;
  uploadedBy: number;
  uploadDate: string;
  expiryDate?: string;
  status: string;
  fileUrl: string;
  onEdit: (document: any) => void;
  onDelete: (document: any) => void;
}

const DocumentCard = ({
  id,
  title,
  type,
  category,
  description,
  uploadDate,
  expiryDate,
  status,
  fileUrl,
  onEdit,
  onDelete,
}: DocumentCardProps) => {
  let fileIcon;
  let bgClass = "bg-blue-100";
  let textClass = "text-primary";
  
  if (type === "policy") {
    fileIcon = <FileText className="h-5 w-5" />;
    bgClass = "bg-purple-100";
    textClass = "text-purple-600";
  } else if (type === "procedure") {
    fileIcon = <FilePlus className="h-5 w-5" />;
    bgClass = "bg-green-100";
    textClass = "text-[#27AE60]";
  } else if (type === "form") {
    fileIcon = <FileEdit className="h-5 w-5" />;
    bgClass = "bg-orange-100";
    textClass = "text-orange-600";
  } else if (type === "report") {
    fileIcon = <File className="h-5 w-5" />;
    bgClass = "bg-yellow-100";
    textClass = "text-yellow-600";
  } else {
    fileIcon = <File className="h-5 w-5" />;
  }
  
  const statusClasses = {
    "active": "bg-green-100 text-green-800",
    "archived": "bg-gray-100 text-gray-800",
    "expired": "bg-red-100 text-red-800",
    "draft": "bg-amber-100 text-amber-800",
  };
  
  const statusClass = statusClasses[status?.toLowerCase() as keyof typeof statusClasses] || "bg-gray-100 text-gray-800";
  
  return (
    <div className="border border-gray-200 rounded-md overflow-hidden shadow-sm hover:shadow transition-all">
      <div className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex">
            <div className={`${bgClass} ${textClass} p-3 rounded-md`}>
              {fileIcon}
            </div>
            <div className="ml-3 flex-1">
              <h3 className="font-medium text-[#2C3E50]">{title}</h3>
              <div className="flex items-center mt-1 gap-2">
                <p className="text-xs text-gray-500 capitalize">{category} • {type}</p>
                <span className={`text-xs px-2 py-0.5 rounded-full ${statusClass}`}>
                  {status}
                </span>
              </div>
            </div>
          </div>
        </div>
        
        {description && (
          <p className="mt-3 text-sm text-gray-600 line-clamp-2">{description}</p>
        )}
        
        <div className="mt-3 flex flex-col gap-1 text-xs text-gray-500">
          <div className="flex items-center">
            <Calendar className="h-3 w-3 mr-1" /> 
            <span>Upload Date: {new Date(uploadDate).toLocaleDateString()}</span>
          </div>
          
          {expiryDate && (
            <div className="flex items-center">
              <Calendar className="h-3 w-3 mr-1" /> 
              <span>Expiry Date: {new Date(expiryDate).toLocaleDateString()}</span>
            </div>
          )}
        </div>
        
        <div className="mt-4 flex justify-end items-center space-x-1">
          <Button 
            variant="ghost" 
            size="icon"
            className="h-8 w-8 text-gray-500 hover:text-primary"
            title="View Document"
            asChild
          >
            <a href={fileUrl} target="_blank" rel="noopener noreferrer">
              <Eye className="h-4 w-4" />
            </a>
          </Button>
          <Button 
            variant="ghost" 
            size="icon"
            className="h-8 w-8 text-gray-500 hover:text-primary"
            title="Download Document"
          >
            <Download className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon"
            className="h-8 w-8 text-gray-500 hover:text-blue-600"
            title="Edit Document"
            onClick={() => onEdit({ id, title, type, category, description, uploadDate, expiryDate, status })}
          >
            <FileEdit className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon"
            className="h-8 w-8 text-gray-500 hover:text-red-600"
            title="Delete Document"
            onClick={() => onDelete({ id, title })}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default function Documents() {
  const [location] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [editDocument, setEditDocument] = useState<any>(null);
  const [documentToDelete, setDocumentToDelete] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Determine which tab to show
  const currentTab = location.includes("type=policy") ? "policies" : "all";
  
  // Fetch documents data
  const { data: documents, isLoading } = useQuery({
    queryKey: ['/api/documents'],
  });
  
  // Delete document mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/documents/${id}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/documents'] });
      toast({
        title: "Document deleted",
        description: "The document has been successfully deleted.",
      });
      setIsDeleteDialogOpen(false);
      setDocumentToDelete(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete document: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const handleEditDocument = (document: any) => {
    setEditDocument(document);
    setIsUploadDialogOpen(true);
  };
  
  const handleDeleteDocument = (document: any) => {
    setDocumentToDelete(document);
    setIsDeleteDialogOpen(true);
  };
  
  const confirmDelete = () => {
    if (documentToDelete) {
      deleteMutation.mutate(documentToDelete.id);
    }
  };
  
  const filteredDocuments = documents
    ? documents.filter((doc: any) => {
        // Search filter
        const matchesSearch = !searchTerm || 
          doc.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          doc.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (doc.description && doc.description.toLowerCase().includes(searchTerm.toLowerCase()));
          
        // Tab filter
        const matchesTab = currentTab === "all" || 
          (currentTab === "policies" && doc.type === "policy");
          
        return matchesSearch && matchesTab;
      })
    : [];

  return (
    <>
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the document
              "{documentToDelete?.title}" and remove it from the system.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Card className="shadow">
        <CardHeader className="pb-3">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <CardTitle className="text-2xl font-bold text-[#2C3E50]">Document Management</CardTitle>
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Search documents..."
                  className="pl-10 w-full sm:w-64"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <i className="ri-search-line absolute left-3 top-2.5 text-gray-400"></i>
              </div>
              <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary hover:bg-primary/90 text-white">
                    <i className="ri-upload-line mr-1"></i> Upload Document
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[525px]">
                  <DialogHeader>
                    <DialogTitle>{editDocument ? "Edit Document" : "Upload New Document"}</DialogTitle>
                    <DialogDescription>
                      {editDocument ? "Edit document details" : "Upload a safety document, policy, or procedure"}
                    </DialogDescription>
                  </DialogHeader>
                  
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem className="grid grid-cols-4 items-center gap-4">
                            <FormLabel className="text-right">Title</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Document title" 
                                className="col-span-3" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage className="col-span-3 col-start-2" />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="type"
                        render={({ field }) => (
                          <FormItem className="grid grid-cols-4 items-center gap-4">
                            <FormLabel className="text-right">Type</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger className="col-span-3">
                                  <SelectValue placeholder="Select document type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="policy">Policy</SelectItem>
                                <SelectItem value="procedure">Procedure</SelectItem>
                                <SelectItem value="form">Form</SelectItem>
                                <SelectItem value="report">Report</SelectItem>
                                <SelectItem value="manual">Manual</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage className="col-span-3 col-start-2" />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem className="grid grid-cols-4 items-center gap-4">
                            <FormLabel className="text-right">Category</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Safety, Training, Compliance, etc." 
                                className="col-span-3" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage className="col-span-3 col-start-2" />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem className="grid grid-cols-4 items-start gap-4">
                            <FormLabel className="text-right pt-2">Description</FormLabel>
                            <FormControl>
                              <Textarea
                                placeholder="Brief description of the document" 
                                className="col-span-3"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage className="col-span-3 col-start-2" />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="uploadDate"
                        render={({ field }) => (
                          <FormItem className="grid grid-cols-4 items-center gap-4">
                            <FormLabel className="text-right">Upload Date</FormLabel>
                            <div className="col-span-3">
                              <Popover>
                                <PopoverTrigger asChild>
                                  <FormControl>
                                    <Button
                                      variant={"outline"}
                                      className={cn(
                                        "w-full pl-3 text-left font-normal",
                                        !field.value && "text-muted-foreground"
                                      )}
                                    >
                                      {field.value ? (
                                        format(new Date(field.value), "PPP")
                                      ) : (
                                        <span>Select date</span>
                                      )}
                                      <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                    </Button>
                                  </FormControl>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                  <Calendar
                                    mode="single"
                                    selected={field.value ? new Date(field.value) : undefined}
                                    onSelect={field.onChange}
                                    initialFocus
                                  />
                                </PopoverContent>
                              </Popover>
                            </div>
                            <FormMessage className="col-span-3 col-start-2" />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="expiryDate"
                        render={({ field }) => (
                          <FormItem className="grid grid-cols-4 items-center gap-4">
                            <FormLabel className="text-right">Expiry Date</FormLabel>
                            <div className="col-span-3">
                              <Popover>
                                <PopoverTrigger asChild>
                                  <FormControl>
                                    <Button
                                      variant={"outline"}
                                      className={cn(
                                        "w-full pl-3 text-left font-normal",
                                        !field.value && "text-muted-foreground"
                                      )}
                                    >
                                      {field.value ? (
                                        format(new Date(field.value), "PPP")
                                      ) : (
                                        <span>Select date (optional)</span>
                                      )}
                                      <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                    </Button>
                                  </FormControl>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                  <Calendar
                                    mode="single"
                                    selected={field.value ? new Date(field.value) : undefined}
                                    onSelect={field.onChange}
                                    initialFocus
                                  />
                                </PopoverContent>
                              </Popover>
                            </div>
                            <FormMessage className="col-span-3 col-start-2" />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="status"
                        render={({ field }) => (
                          <FormItem className="grid grid-cols-4 items-center gap-4">
                            <FormLabel className="text-right">Status</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value || "active"}
                            >
                              <FormControl>
                                <SelectTrigger className="col-span-3">
                                  <SelectValue placeholder="Select status" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="active">Active</SelectItem>
                                <SelectItem value="draft">Draft</SelectItem>
                                <SelectItem value="archived">Archived</SelectItem>
                                <SelectItem value="expired">Expired</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage className="col-span-3 col-start-2" />
                          </FormItem>
                        )}
                      />
                      
                      {!editDocument && (
                        <FormField
                          control={form.control}
                          name="file"
                          render={({ field: { value, onChange, ...field } }) => (
                            <FormItem className="grid grid-cols-4 items-center gap-4">
                              <FormLabel className="text-right">File</FormLabel>
                              <FormControl>
                                <Input
                                  type="file"
                                  className="col-span-3"
                                  onChange={(e) => {
                                    const file = e.target.files?.[0];
                                    if (file) {
                                      onChange(file);
                                    }
                                  }}
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage className="col-span-3 col-start-2" />
                            </FormItem>
                          )}
                        />
                      )}
                      
                      <DialogFooter>
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => {
                            setIsUploadDialogOpen(false);
                            setEditDocument(null);
                            form.reset();
                          }}
                        >
                          Cancel
                        </Button>
                        <Button 
                          type="submit" 
                          className="bg-primary hover:bg-primary/90 text-white"
                          disabled={form.formState.isSubmitting}
                        >
                          {form.formState.isSubmitting ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              {editDocument ? "Saving..." : "Uploading..."}
                            </>
                          ) : (
                            editDocument ? "Save Document" : "Upload Document"
                          )}
                        </Button>
                      </DialogFooter>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue={currentTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="all">All Documents</TabsTrigger>
              <TabsTrigger value="policies">Policies</TabsTrigger>
              <TabsTrigger value="procedures">Procedures</TabsTrigger>
              <TabsTrigger value="forms">Forms</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all" className="mt-0">
              {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {Array(6).fill(0).map((_, i) => (
                    <div key={i} className="border border-gray-200 rounded-md p-4">
                      <div className="flex items-start">
                        <Skeleton className="h-12 w-12 rounded-md" />
                        <div className="ml-3 flex-1">
                          <Skeleton className="h-5 w-40 mb-2" />
                          <Skeleton className="h-4 w-24" />
                        </div>
                      </div>
                      <Skeleton className="h-4 w-full mt-3" />
                      <div className="mt-4 flex justify-between">
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-8 w-16" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredDocuments.length === 0 ? (
                    <div className="col-span-full text-center py-12 text-gray-500">
                      No documents found
                    </div>
                  ) : (
                    filteredDocuments.map((doc: any) => (
                      <DocumentCard
                        key={doc.id}
                        id={doc.id}
                        title={doc.title}
                        type={doc.type}
                        category={doc.category}
                        description={doc.description}
                        uploadedBy={doc.uploadedBy}
                        uploadDate={doc.uploadDate}
                        expiryDate={doc.expiryDate}
                        status={doc.status || "active"}
                        fileUrl={doc.fileUrl}
                        onEdit={handleEditDocument}
                        onDelete={handleDeleteDocument}
                      />
                    ))
                  )}
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="policies" className="mt-0">
              {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {Array(3).fill(0).map((_, i) => (
                    <div key={i} className="border border-gray-200 rounded-md p-4">
                      <div className="flex items-start">
                        <Skeleton className="h-12 w-12 rounded-md" />
                        <div className="ml-3 flex-1">
                          <Skeleton className="h-5 w-40 mb-2" />
                          <Skeleton className="h-4 w-24" />
                        </div>
                      </div>
                      <Skeleton className="h-4 w-full mt-3" />
                      <div className="mt-4 flex justify-between">
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-8 w-16" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredDocuments.length === 0 ? (
                    <div className="col-span-full text-center py-12 text-gray-500">
                      No policies found
                    </div>
                  ) : (
                    filteredDocuments.map((doc: any) => (
                      <DocumentCard
                        key={doc.id}
                        id={doc.id}
                        title={doc.title}
                        type={doc.type}
                        category={doc.category}
                        description={doc.description}
                        uploadedBy={doc.uploadedBy}
                        uploadDate={doc.uploadDate}
                        expiryDate={doc.expiryDate}
                        status={doc.status || "active"}
                        fileUrl={doc.fileUrl}
                        onEdit={handleEditDocument}
                        onDelete={handleDeleteDocument}
                      />
                    ))
                  )}
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="procedures" className="mt-0">
              <div className="text-center py-12 text-gray-500">
                Select a different document type
              </div>
            </TabsContent>
            
            <TabsContent value="forms" className="mt-0">
              <div className="text-center py-12 text-gray-500">
                Select a different document type
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </>
  );
}
