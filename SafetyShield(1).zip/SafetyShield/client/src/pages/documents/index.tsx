import { useState } from "react";
import DocumentList from "@/components/documents/DocumentList";
import DocumentUpload from "@/components/documents/DocumentUpload";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const DocumentsPage = () => {
  const [activeTab, setActiveTab] = useState("library");
  
  return (
    <div className="space-y-6">
      <Tabs 
        defaultValue="library" 
        value={activeTab} 
        onValueChange={setActiveTab}
        className="w-full"
      >
        <TabsList className="grid w-full md:w-[400px] grid-cols-2">
          <TabsTrigger value="library">Document Library</TabsTrigger>
          <TabsTrigger value="upload">Upload Document</TabsTrigger>
        </TabsList>
        <TabsContent value="library">
          <DocumentList />
        </TabsContent>
        <TabsContent value="upload">
          <DocumentUpload />
        </TabsContent>
      </Tabs>
      
      {/* Bottom spacing */}
      <div className="h-16"></div>
    </div>
  );
};

export default DocumentsPage;
