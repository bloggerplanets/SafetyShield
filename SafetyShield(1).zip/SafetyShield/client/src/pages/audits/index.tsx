import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { CalendarIcon, ClipboardCheckIcon, PlusIcon, ArrowUpDownIcon, SearchIcon } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const statusColors = {
  "Scheduled": "bg-blue-100 text-blue-800",
  "In Progress": "bg-yellow-100 text-yellow-800",
  "Completed": "bg-green-100 text-green-800",
  "Overdue": "bg-red-100 text-red-800"
};

export default function AuditsPage() {
  // Mock audit data
  const audits = [
    {
      id: 1,
      title: "Annual Safety Audit",
      description: "Comprehensive evaluation of all safety systems and procedures",
      auditType: "Internal",
      location: "Main Facility",
      auditor: "Sarah Mitchell",
      scheduledDate: "2025-04-15",
      status: "Scheduled",
      findings: null
    },
    {
      id: 2,
      title: "Quarterly Fire Safety Inspection",
      description: "Inspection of fire extinguishers, alarms, and evacuation procedures",
      auditType: "Internal",
      location: "Building A",
      auditor: "James Wilson",
      scheduledDate: "2025-03-20",
      status: "In Progress",
      findings: null
    },
    {
      id: 3,
      title: "OSHA Compliance Verification",
      description: "Assessment of compliance with OSHA standards and regulations",
      auditType: "External",
      location: "All Facilities",
      auditor: "External Consultant",
      scheduledDate: "2025-02-10",
      status: "Completed",
      findings: "Minor findings in machine guarding. Corrective actions implemented."
    },
    {
      id: 4,
      title: "Environmental Compliance Audit",
      description: "Review of environmental permits, waste management, and emissions",
      auditType: "External",
      location: "Chemical Storage",
      auditor: "Environmental Agency",
      scheduledDate: "2025-01-05",
      status: "Completed",
      findings: "No significant findings. All processes in compliance."
    }
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Audits</h1>
          <p className="text-gray-500 mt-1">Manage and track internal and external audits</p>
        </div>
        <Button className="flex items-center gap-2">
          <PlusIcon className="h-4 w-4" />
          Schedule New Audit
        </Button>
      </div>
      
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative w-full md:w-72">
          <SearchIcon className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input placeholder="Search audits..." className="pl-8" />
        </div>
        
        <div className="flex gap-2">
          <Select defaultValue="all">
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="scheduled">Scheduled</SelectItem>
              <SelectItem value="in-progress">In Progress</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="overdue">Overdue</SelectItem>
            </SelectContent>
          </Select>
          
          <Select defaultValue="all">
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="internal">Internal</SelectItem>
              <SelectItem value="external">External</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" size="icon">
            <ArrowUpDownIcon className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <Tabs defaultValue="upcoming">
        <TabsList>
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
          <TabsTrigger value="findings">Findings & Actions</TabsTrigger>
          <TabsTrigger value="statistics">Statistics</TabsTrigger>
        </TabsList>
        
        <TabsContent value="upcoming" className="mt-6 space-y-4">
          {audits
            .filter(audit => ["Scheduled", "In Progress"].includes(audit.status))
            .map(audit => (
              <Card key={audit.id}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between">
                    <CardTitle>{audit.title}</CardTitle>
                    <Badge className={statusColors[audit.status as keyof typeof statusColors]}>
                      {audit.status}
                    </Badge>
                  </div>
                  <CardDescription>{audit.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-gray-500">Audit Type</p>
                      <p>{audit.auditType}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Location</p>
                      <p>{audit.location}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Auditor</p>
                      <p>{audit.auditor}</p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <div className="flex items-center text-sm text-gray-500">
                    <CalendarIcon className="mr-1 h-4 w-4" />
                    <span>Scheduled: {new Date(audit.scheduledDate).toLocaleDateString()}</span>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">View Details</Button>
                    <Button size="sm">
                      <ClipboardCheckIcon className="mr-1 h-4 w-4" />
                      Conduct Audit
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            ))}
        </TabsContent>
        
        <TabsContent value="completed" className="mt-6 space-y-4">
          {audits
            .filter(audit => audit.status === "Completed")
            .map(audit => (
              <Card key={audit.id}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between">
                    <CardTitle>{audit.title}</CardTitle>
                    <Badge className="bg-green-100 text-green-800">
                      {audit.status}
                    </Badge>
                  </div>
                  <CardDescription>{audit.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-gray-500">Audit Type</p>
                      <p>{audit.auditType}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Location</p>
                      <p>{audit.location}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Auditor</p>
                      <p>{audit.auditor}</p>
                    </div>
                  </div>
                  
                  {audit.findings && (
                    <div className="mt-4">
                      <p className="text-gray-500 text-sm">Findings</p>
                      <p className="text-sm">{audit.findings}</p>
                    </div>
                  )}
                </CardContent>
                <CardFooter className="flex justify-between">
                  <div className="flex items-center text-sm text-gray-500">
                    <CalendarIcon className="mr-1 h-4 w-4" />
                    <span>Completed: {new Date(audit.scheduledDate).toLocaleDateString()}</span>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">Download Report</Button>
                    <Button variant="outline" size="sm">View Details</Button>
                  </div>
                </CardFooter>
              </Card>
            ))}
        </TabsContent>
        
        <TabsContent value="findings" className="mt-6">
          <Card>
            <CardContent className="pt-6">
              <p className="text-center text-gray-500 py-12">No findings requiring action at this time.</p>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="statistics" className="mt-6">
          <Card>
            <CardContent className="pt-6">
              <p className="text-center text-gray-500 py-12">Audit statistics will be available soon.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}