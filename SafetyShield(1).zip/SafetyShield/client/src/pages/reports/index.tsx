import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart3Icon, FileIcon, DownloadIcon } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function ReportsPage() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Reports</h1>
          <p className="text-gray-500 mt-1">Generate and view EHS performance reports</p>
        </div>
      </div>
      
      <Tabs defaultValue="standard">
        <TabsList>
          <TabsTrigger value="standard">Standard Reports</TabsTrigger>
          <TabsTrigger value="custom">Custom Reports</TabsTrigger>
          <TabsTrigger value="scheduled">Scheduled Reports</TabsTrigger>
          <TabsTrigger value="saved">Saved Reports</TabsTrigger>
        </TabsList>
        
        <TabsContent value="standard" className="mt-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Standard Reports</h2>
            <div className="flex gap-2">
              <Select defaultValue="current">
                <SelectTrigger className="w-[160px]">
                  <SelectValue placeholder="Time Period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="current">Current Month</SelectItem>
                  <SelectItem value="last">Last Month</SelectItem>
                  <SelectItem value="quarter">Current Quarter</SelectItem>
                  <SelectItem value="year">Current Year</SelectItem>
                  <SelectItem value="custom">Custom Range</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ReportCard 
              title="Incident Summary"
              description="Summary of all incidents by type, severity, and location"
              icon={<BarChart3Icon className="h-6 w-6" />}
            />
            
            <ReportCard 
              title="Compliance Status"
              description="Compliance metrics and status by standard or requirement"
              icon={<BarChart3Icon className="h-6 w-6" />}
            />
            
            <ReportCard 
              title="Audit Findings"
              description="Summary of audit findings and corrective actions"
              icon={<BarChart3Icon className="h-6 w-6" />}
            />
            
            <ReportCard 
              title="Risk Assessment"
              description="Comprehensive risk assessment by category and location"
              icon={<BarChart3Icon className="h-6 w-6" />}
            />
            
            <ReportCard 
              title="Training Completion"
              description="Employee training completion rates and status"
              icon={<BarChart3Icon className="h-6 w-6" />}
            />
            
            <ReportCard 
              title="Safety Metrics"
              description="Key safety performance indicators and trends"
              icon={<BarChart3Icon className="h-6 w-6" />}
            />
          </div>
        </TabsContent>
        
        <TabsContent value="custom" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Custom Report Builder</CardTitle>
              <CardDescription>Create a custom report by selecting metrics and filters</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-center text-gray-500 py-12">Custom report builder coming soon</p>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="scheduled" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Scheduled Reports</CardTitle>
              <CardDescription>Configure reports to be automatically generated and sent</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-center text-gray-500 py-12">No scheduled reports configured</p>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="saved" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Saved Reports</CardTitle>
              <CardDescription>Your saved and recently generated reports</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-center text-gray-500 py-12">No saved reports found</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

interface ReportCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
}

function ReportCard({ title, description, icon }: ReportCardProps) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-md bg-primary/10 text-primary">
            {icon}
          </div>
          <CardTitle>{title}</CardTitle>
        </div>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex justify-between pt-2">
          <Button variant="outline" className="flex items-center gap-2">
            <FileIcon className="h-4 w-4" />
            Preview
          </Button>
          <Button className="flex items-center gap-2">
            <DownloadIcon className="h-4 w-4" />
            Generate
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}