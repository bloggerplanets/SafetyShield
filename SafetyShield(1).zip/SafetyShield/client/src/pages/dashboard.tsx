import DashboardSummary from "@/components/dashboard/DashboardSummary";
import RecentIncidents from "@/components/dashboard/RecentIncidents";
import QuickActions from "@/components/dashboard/QuickActions";
import UpcomingTasks from "@/components/dashboard/UpcomingTasks";
import ComplianceStatus from "@/components/dashboard/ComplianceStatus";

const Dashboard = () => {
  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <DashboardSummary />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Incidents */}
        <RecentIncidents />
        
        {/* Quick Actions and Upcoming Tasks */}
        <div className="space-y-6">
          <QuickActions />
          <UpcomingTasks />
        </div>
      </div>
      
      {/* Compliance Status */}
      <ComplianceStatus />
      
      {/* Bottom spacing */}
      <div className="h-16"></div>
    </div>
  );
};

export default Dashboard;
