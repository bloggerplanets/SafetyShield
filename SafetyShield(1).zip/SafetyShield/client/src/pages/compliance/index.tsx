import { useState } from "react";
import ComplianceTracker from "@/components/compliance/ComplianceTracker";
import AuditSchedule from "@/components/compliance/AuditSchedule";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const CompliancePage = () => {
  const [activeTab, setActiveTab] = useState("compliance");
  
  return (
    <div className="space-y-6">
      <Tabs 
        defaultValue="compliance" 
        value={activeTab} 
        onValueChange={setActiveTab}
        className="w-full"
      >
        <TabsList className="grid w-full md:w-[400px] grid-cols-2">
          <TabsTrigger value="compliance">Compliance Status</TabsTrigger>
          <TabsTrigger value="audits">Audit Schedule</TabsTrigger>
        </TabsList>
        <TabsContent value="compliance">
          <ComplianceTracker />
        </TabsContent>
        <TabsContent value="audits">
          <AuditSchedule />
        </TabsContent>
      </Tabs>
      
      {/* Bottom spacing */}
      <div className="h-16"></div>
    </div>
  );
};

export default CompliancePage;
