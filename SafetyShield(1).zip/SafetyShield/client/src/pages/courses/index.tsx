import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { GraduationCapIcon, BookOpenIcon, Clock } from "lucide-react";

export default function CoursesPage() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Training & Courses</h1>
          <p className="text-gray-500 mt-1">Manage and track employee training programs</p>
        </div>
        <Button className="flex items-center gap-2">
          <GraduationCapIcon className="h-4 w-4" />
          Create New Course
        </Button>
      </div>

      <Tabs defaultValue="available">
        <TabsList>
          <TabsTrigger value="available">Available Courses</TabsTrigger>
          <TabsTrigger value="enrolled">My Enrollments</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
          <TabsTrigger value="management">Course Management</TabsTrigger>
        </TabsList>
        
        <TabsContent value="available" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i}>
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <CardTitle>Safety Leadership</CardTitle>
                    <Badge>Required</Badge>
                  </div>
                  <CardDescription>Management & Leadership</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <div className="flex items-center">
                        <Clock className="mr-1 h-4 w-4 text-primary" />
                        <span>2 hours</span>
                      </div>
                      <div className="flex items-center">
                        <BookOpenIcon className="mr-1 h-4 w-4 text-primary" />
                        <span>5 modules</span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-500">Learn essential safety leadership principles and how to promote a safety culture in your organization.</p>
                    <Button className="w-full mt-2">Enroll Now</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="enrolled" className="mt-6">
          <div className="grid grid-cols-1 gap-4">
            <p className="text-center text-gray-500 py-12">You are not currently enrolled in any courses.</p>
          </div>
        </TabsContent>
        
        <TabsContent value="completed" className="mt-6">
          <div className="grid grid-cols-1 gap-4">
            <p className="text-center text-gray-500 py-12">You have not completed any courses yet.</p>
          </div>
        </TabsContent>
        
        <TabsContent value="management" className="mt-6">
          <div className="grid grid-cols-1 gap-4">
            <p className="text-center text-gray-500 py-12">You do not have permissions to manage courses.</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}