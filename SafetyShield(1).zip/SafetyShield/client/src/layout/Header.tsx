import { useLocation } from "wouter";
import { BellIcon, HelpCircleIcon, MenuIcon } from "lucide-react";

interface HeaderProps {
  mobileMenuOpen: boolean;
  toggleMobileMenu: () => void;
}

const Header = ({ toggleMobileMenu }: HeaderProps) => {
  const [location] = useLocation();
  
  // Get current page title based on location
  const getPageTitle = () => {
    switch(true) {
      case location === "/":
        return "Dashboard";
      case location === "/incidents":
        return "Incident Dashboard";
      case location === "/incidents/report":
        return "Report Incident";
      case location === "/documents":
        return "Documents";
      case location === "/compliance":
        return "Compliance Tracking";
      case location === "/risk":
        return "Risk Assessment";
      default:
        return "Dashboard";
    }
  };
  
  // Get page description based on location
  const getPageDescription = () => {
    switch(true) {
      case location === "/":
        return "Overview of your EHS performance";
      case location === "/incidents":
        return "View and manage incidents";
      case location === "/incidents/report":
        return "Report a new incident";
      case location === "/documents":
        return "Manage safety documents and policies";
      case location === "/compliance":
        return "Track compliance status and deadlines";
      case location === "/risk":
        return "Hazard identification and risk assessment";
      default:
        return "Overview of your EHS performance";
    }
  };
  
  return (
    <header className="bg-white shadow-sm z-10">
      <div className="flex items-center justify-between h-16 px-4">
        <div className="flex items-center">
          <button 
            className="md:hidden p-2 rounded-md hover:bg-gray-100"
            onClick={toggleMobileMenu}
          >
            <MenuIcon className="w-6 h-6" />
          </button>
          <div className="ml-2 md:ml-0">
            <h2 className="text-lg font-semibold">{getPageTitle()}</h2>
            <p className="text-sm text-gray-500 hidden sm:block">{getPageDescription()}</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="p-1 rounded-full hover:bg-gray-100">
            <BellIcon className="w-6 h-6" />
          </button>
          <button className="p-1 rounded-full hover:bg-gray-100">
            <HelpCircleIcon className="w-6 h-6" />
          </button>
          <div className="relative md:hidden">
            <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center">
              <span className="text-sm font-medium">SM</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
