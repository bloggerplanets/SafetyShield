import { useState, useEffect } from "react";
import Sidebar from "./Sidebar";
import Header from "./Header";

interface AppLayoutProps {
  children: React.ReactNode;
}

const AppLayout = ({ children }: AppLayoutProps) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Close mobile menu when window size increases
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768 && mobileMenuOpen) {
        setMobileMenuOpen(false);
      }
    };
    
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [mobileMenuOpen]);
  
  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar Navigation */}
      <Sidebar isOpen={mobileMenuOpen} />
      
      {/* Mobile navigation overlay */}
      {mobileMenuOpen && (
        <div 
          className="md:hidden fixed inset-0 z-20 bg-black bg-opacity-50"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}
      
      {/* Main Content Area */}
      <div className="flex flex-col flex-1 overflow-hidden">
        {/* Top navigation */}
        <Header 
          mobileMenuOpen={mobileMenuOpen} 
          toggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)} 
        />
        
        {/* Main content */}
        <main className="flex-1 overflow-y-auto p-4 bg-neutral">
          {children}
        </main>
      </div>
    </div>
  );
};

export default AppLayout;
