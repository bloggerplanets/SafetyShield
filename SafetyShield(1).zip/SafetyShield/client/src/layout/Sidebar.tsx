import { Link, useLocation } from "wouter";
import { 
  HomeIcon, 
  ClipboardIcon, 
  FileTextIcon, 
  GanttChartIcon, 
  AlertTriangleIcon, 
  CalendarIcon, 
  BarChart3Icon,
  Settings,
  ChevronDownIcon,
  GraduationCapIcon,
  UserIcon
} from "lucide-react";

interface SidebarProps {
  isOpen: boolean;
}

const Sidebar = ({ isOpen }: SidebarProps) => {
  const [location] = useLocation();
  
  const isActive = (path: string) => {
    return location === path;
  };
  
  const isInPath = (path: string) => {
    return location.startsWith(path);
  };

  // Navigation item component
  const NavItem = ({ href, icon, label }: { href: string; icon: React.ReactNode; label: string }) => (
    <Link href={href}>
      <div className={`flex items-center px-4 py-2 text-sm font-medium rounded-md cursor-pointer ${isActive(href) ? "sidebar-menu-item active" : "hover:bg-gray-50"}`}>
        {icon}
        {label}
      </div>
    </Link>
  );
  
  // Submenu item component
  const SubNavItem = ({ href, label }: { href: string; label: string }) => (
    <Link href={href}>
      <div className={`flex items-center pl-8 pr-2 py-2 text-sm font-medium rounded-md cursor-pointer ${isActive(href) ? "bg-gray-50 text-primary" : "hover:bg-gray-50"}`}>
        {label}
      </div>
    </Link>
  );
  
  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden md:flex md:flex-col w-64 bg-white shadow-lg">
        <div className="flex items-center justify-center h-16 border-b border-gray-200">
          <h1 className="text-xl font-bold text-primary">EHS Management</h1>
        </div>
        
        <div className="flex flex-col flex-grow overflow-y-auto">
          <nav className="flex-1 px-2 py-4 space-y-1">
            <NavItem 
              href="/" 
              icon={<HomeIcon className="w-5 h-5 mr-3" />} 
              label="Dashboard" 
            />
            
            <div className="space-y-1">
              <button className={`flex items-center justify-between w-full px-4 py-2 text-sm font-medium text-left rounded-md ${isInPath("/incidents") ? "sidebar-menu-item active" : "hover:bg-gray-50"}`}>
                <div className="flex items-center">
                  <ClipboardIcon className="w-5 h-5 mr-3" />
                  Incidents
                </div>
                <ChevronDownIcon className="w-5 h-5" />
              </button>
              
              <div className="pl-4 pr-1 space-y-1">
                <SubNavItem href="/incidents/report" label="Report Incident" />
                <SubNavItem href="/incidents" label="Incident Dashboard" />
              </div>
            </div>
            
            <NavItem 
              href="/documents" 
              icon={<FileTextIcon className="w-5 h-5 mr-3" />} 
              label="Documents" 
            />
            
            <NavItem 
              href="/compliance" 
              icon={<GanttChartIcon className="w-5 h-5 mr-3" />} 
              label="Compliance" 
            />
            
            <NavItem 
              href="/risk" 
              icon={<AlertTriangleIcon className="w-5 h-5 mr-3" />} 
              label="Risk Assessment" 
            />
            
            <NavItem 
              href="/audits" 
              icon={<CalendarIcon className="w-5 h-5 mr-3" />} 
              label="Audits" 
            />
            
            <NavItem 
              href="/reports" 
              icon={<BarChart3Icon className="w-5 h-5 mr-3" />} 
              label="Reports" 
            />
            
            <NavItem 
              href="/courses" 
              icon={<GraduationCapIcon className="w-5 h-5 mr-3" />} 
              label="Training & Courses" 
            />
            
            <NavItem 
              href="/calendar" 
              icon={<CalendarIcon className="w-5 h-5 mr-3" />} 
              label="Calendar" 
            />
            
            <NavItem 
              href="/login" 
              icon={<UserIcon className="w-5 h-5 mr-3" />} 
              label="Login" 
            />
            
            <NavItem 
              href="/settings" 
              icon={<Settings className="w-5 h-5 mr-3" />} 
              label="Settings" 
            />
          </nav>
        </div>
        
        <div className="flex items-center px-4 py-3 border-t border-gray-200">
          <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center">
            <span className="text-sm font-medium">SM</span>
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium">Sarah Mitchell</p>
            <p className="text-xs text-gray-500">Safety Manager</p>
          </div>
        </div>
      </aside>
      
      {/* Mobile sidebar */}
      <div className={`md:hidden fixed inset-y-0 left-0 z-30 w-64 bg-white transform ${isOpen ? 'translate-x-0' : '-translate-x-full'} transition duration-300 ease-in-out`}>
        <div className="flex items-center justify-center h-16 border-b border-gray-200">
          <h1 className="text-xl font-bold text-primary">EHS Management</h1>
        </div>
        
        <div className="flex flex-col flex-grow overflow-y-auto">
          <nav className="flex-1 px-2 py-4 space-y-1">
            <NavItem 
              href="/" 
              icon={<HomeIcon className="w-5 h-5 mr-3" />} 
              label="Dashboard" 
            />
            
            <div className="space-y-1">
              <button className={`flex items-center justify-between w-full px-4 py-2 text-sm font-medium text-left rounded-md ${isInPath("/incidents") ? "sidebar-menu-item active" : "hover:bg-gray-50"}`}>
                <div className="flex items-center">
                  <ClipboardIcon className="w-5 h-5 mr-3" />
                  Incidents
                </div>
                <ChevronDownIcon className="w-5 h-5" />
              </button>
              
              <div className="pl-4 pr-1 space-y-1">
                <SubNavItem href="/incidents/report" label="Report Incident" />
                <SubNavItem href="/incidents" label="Incident Dashboard" />
              </div>
            </div>
            
            <NavItem 
              href="/documents" 
              icon={<FileTextIcon className="w-5 h-5 mr-3" />} 
              label="Documents" 
            />
            
            <NavItem 
              href="/compliance" 
              icon={<GanttChartIcon className="w-5 h-5 mr-3" />} 
              label="Compliance" 
            />
            
            <NavItem 
              href="/risk" 
              icon={<AlertTriangleIcon className="w-5 h-5 mr-3" />} 
              label="Risk Assessment" 
            />
            
            <NavItem 
              href="/audits" 
              icon={<CalendarIcon className="w-5 h-5 mr-3" />} 
              label="Audits" 
            />
            
            <NavItem 
              href="/reports" 
              icon={<BarChart3Icon className="w-5 h-5 mr-3" />} 
              label="Reports" 
            />
            
            <NavItem 
              href="/courses" 
              icon={<GraduationCapIcon className="w-5 h-5 mr-3" />} 
              label="Training & Courses" 
            />
            
            <NavItem 
              href="/calendar" 
              icon={<CalendarIcon className="w-5 h-5 mr-3" />} 
              label="Calendar" 
            />
            
            <NavItem 
              href="/login" 
              icon={<UserIcon className="w-5 h-5 mr-3" />} 
              label="Login" 
            />
            
            <NavItem 
              href="/settings" 
              icon={<Settings className="w-5 h-5 mr-3" />} 
              label="Settings" 
            />
          </nav>
        </div>
      </div>
    </>
  );
};

export default Sidebar;