import { 
  users, type User, type InsertUser,
  incidents, type Incident, type InsertIncident,
  documents, type Document, type InsertDocument,
  complianceItems, type ComplianceItem, type InsertComplianceItem,
  audits, type Audit, type InsertAudit,
  riskAssessments, type RiskAssessment, type InsertRiskAssessment,
  tasks, type Task, type InsertTask,
  courses, type Course, type InsertCourse,
  courseModules, type CourseModule, type InsertCourseModule,
  courseEnrollments, type CourseEnrollment, type InsertEnrollment,
  calendarEvents, type CalendarEvent, type InsertCalendarEvent,
  eventAttendees, type EventAttendee, type InsertEventAttendee
} from "@shared/schema";

export interface IStorage {
  // Users (keeping original methods)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Incidents
  getIncidents(): Promise<Incident[]>;
  getIncident(id: number): Promise<Incident | undefined>;
  createIncident(incident: InsertIncident): Promise<Incident>;
  updateIncident(id: number, incident: Partial<InsertIncident>): Promise<Incident | undefined>;
  deleteIncident(id: number): Promise<boolean>;
  
  // Documents
  getDocuments(): Promise<Document[]>;
  getDocument(id: number): Promise<Document | undefined>;
  createDocument(document: InsertDocument): Promise<Document>;
  updateDocument(id: number, document: Partial<InsertDocument>): Promise<Document | undefined>;
  deleteDocument(id: number): Promise<boolean>;
  
  // Compliance Items
  getComplianceItems(): Promise<ComplianceItem[]>;
  getComplianceItem(id: number): Promise<ComplianceItem | undefined>;
  createComplianceItem(item: InsertComplianceItem): Promise<ComplianceItem>;
  updateComplianceItem(id: number, item: Partial<InsertComplianceItem>): Promise<ComplianceItem | undefined>;
  deleteComplianceItem(id: number): Promise<boolean>;
  
  // Audits
  getAudits(): Promise<Audit[]>;
  getAudit(id: number): Promise<Audit | undefined>;
  createAudit(audit: InsertAudit): Promise<Audit>;
  updateAudit(id: number, audit: Partial<InsertAudit>): Promise<Audit | undefined>;
  deleteAudit(id: number): Promise<boolean>;
  
  // Risk Assessments
  getRiskAssessments(): Promise<RiskAssessment[]>;
  getRiskAssessment(id: number): Promise<RiskAssessment | undefined>;
  createRiskAssessment(assessment: InsertRiskAssessment): Promise<RiskAssessment>;
  updateRiskAssessment(id: number, assessment: Partial<InsertRiskAssessment>): Promise<RiskAssessment | undefined>;
  deleteRiskAssessment(id: number): Promise<boolean>;
  
  // Tasks
  getTasks(): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<InsertTask>): Promise<Task | undefined>;
  deleteTask(id: number): Promise<boolean>;
  
  // Learning Management System (LMS)
  // Courses
  getCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: number, course: Partial<InsertCourse>): Promise<Course | undefined>;
  deleteCourse(id: number): Promise<boolean>;
  
  // Course Modules
  getCourseModules(courseId: number): Promise<CourseModule[]>;
  getCourseModule(id: number): Promise<CourseModule | undefined>;
  createCourseModule(module: InsertCourseModule): Promise<CourseModule>;
  updateCourseModule(id: number, module: Partial<InsertCourseModule>): Promise<CourseModule | undefined>;
  deleteCourseModule(id: number): Promise<boolean>;
  
  // Course Enrollments
  getEnrollments(userId?: number, courseId?: number): Promise<CourseEnrollment[]>;
  getEnrollment(id: number): Promise<CourseEnrollment | undefined>;
  createEnrollment(enrollment: InsertEnrollment): Promise<CourseEnrollment>;
  updateEnrollment(id: number, enrollment: Partial<InsertEnrollment>): Promise<CourseEnrollment | undefined>;
  deleteEnrollment(id: number): Promise<boolean>;
  
  // Calendar
  // Calendar Events
  getCalendarEvents(startDate?: Date, endDate?: Date): Promise<CalendarEvent[]>;
  getCalendarEvent(id: number): Promise<CalendarEvent | undefined>;
  createCalendarEvent(event: InsertCalendarEvent): Promise<CalendarEvent>;
  updateCalendarEvent(id: number, event: Partial<InsertCalendarEvent>): Promise<CalendarEvent | undefined>;
  deleteCalendarEvent(id: number): Promise<boolean>;
  
  // Event Attendees
  getEventAttendees(eventId: number): Promise<EventAttendee[]>;
  getEventAttendee(id: number): Promise<EventAttendee | undefined>;
  createEventAttendee(attendee: InsertEventAttendee): Promise<EventAttendee>;
  updateEventAttendee(id: number, attendee: Partial<InsertEventAttendee>): Promise<EventAttendee | undefined>;
  deleteEventAttendee(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private incidents: Map<number, Incident>;
  private documents: Map<number, Document>;
  private complianceItems: Map<number, ComplianceItem>;
  private audits: Map<number, Audit>;
  private riskAssessments: Map<number, RiskAssessment>;
  private tasks: Map<number, Task>;
  private courses: Map<number, Course>;
  private courseModules: Map<number, CourseModule>;
  private courseEnrollments: Map<number, CourseEnrollment>;
  private calendarEvents: Map<number, CalendarEvent>;
  private eventAttendees: Map<number, EventAttendee>;
  
  private currentUserID: number;
  private currentIncidentID: number;
  private currentDocumentID: number;
  private currentComplianceItemID: number;
  private currentAuditID: number;
  private currentRiskAssessmentID: number;
  private currentTaskID: number;
  private currentCourseID: number;
  private currentCourseModuleID: number;
  private currentEnrollmentID: number;
  private currentEventID: number;
  private currentAttendeeID: number;

  constructor() {
    this.users = new Map();
    this.incidents = new Map();
    this.documents = new Map();
    this.complianceItems = new Map();
    this.audits = new Map();
    this.riskAssessments = new Map();
    this.tasks = new Map();
    this.courses = new Map();
    this.courseModules = new Map();
    this.courseEnrollments = new Map();
    this.calendarEvents = new Map();
    this.eventAttendees = new Map();
    
    this.currentUserID = 1;
    this.currentIncidentID = 1;
    this.currentDocumentID = 1;
    this.currentComplianceItemID = 1;
    this.currentAuditID = 1;
    this.currentRiskAssessmentID = 1;
    this.currentTaskID = 1;
    this.currentCourseID = 1;
    this.currentCourseModuleID = 1;
    this.currentEnrollmentID = 1;
    this.currentEventID = 1;
    this.currentAttendeeID = 1;
    
    // Add some initial data
    this.initializeData();
  }

  private initializeData() {
    // Initialize with demo data
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const next30Days = new Date(now);
    next30Days.setDate(next30Days.getDate() + 30);
    
    // Example compliance items
    [
      {
        name: "Hazard Communication",
        standard: "OSHA",
        category: "Hazard Communication",
        description: "Maintain compliance with OSHA's HazCom standard",
        dueDate: next30Days,
        status: "Compliant",
        percentComplete: 100,
        assignedTo: "Safety Manager"
      },
      {
        name: "Respiratory Protection",
        standard: "OSHA",
        category: "Respiratory Protection",
        description: "Ensure respirator program is compliant",
        dueDate: next30Days,
        status: "Compliant",
        percentComplete: 95,
        assignedTo: "Safety Manager"
      },
      {
        name: "Emergency Action Plans",
        standard: "OSHA",
        category: "Emergency Preparedness",
        description: "Update and maintain emergency action plans",
        dueDate: next30Days,
        status: "In Progress",
        percentComplete: 88,
        assignedTo: "EHS Coordinator"
      },
      {
        name: "Machine Guarding",
        standard: "OSHA",
        category: "Machine Safety",
        description: "Ensure all equipment has proper guarding",
        dueDate: next30Days,
        status: "In Progress",
        percentComplete: 85,
        assignedTo: "Maintenance Manager"
      },
      {
        name: "Leadership & Commitment",
        standard: "ISO 45001",
        category: "Management",
        description: "Demonstrate leadership commitment to safety",
        dueDate: next30Days,
        status: "Compliant",
        percentComplete: 90,
        assignedTo: "Plant Manager"
      },
      {
        name: "Risk Assessment",
        standard: "ISO 45001",
        category: "Risk Management",
        description: "Implement risk assessment process",
        dueDate: next30Days,
        status: "In Progress",
        percentComplete: 85,
        assignedTo: "Safety Manager"
      },
      {
        name: "Performance Evaluation",
        standard: "ISO 45001",
        category: "Monitoring",
        description: "Evaluate safety performance and metrics",
        dueDate: next30Days,
        status: "Non-Compliant",
        percentComplete: 75,
        assignedTo: "Safety Manager"
      },
      {
        name: "Document Control",
        standard: "ISO 45001",
        category: "Documentation",
        description: "Maintain document control system",
        dueDate: next30Days,
        status: "In Progress",
        percentComplete: 82,
        assignedTo: "Document Controller"
      },
      {
        name: "Personal Protective Equipment",
        standard: "Internal",
        category: "PPE",
        description: "Ensure PPE is available and properly used",
        dueDate: next30Days,
        status: "Compliant",
        percentComplete: 97,
        assignedTo: "Safety Manager"
      },
      {
        name: "Training Requirements",
        standard: "Internal",
        category: "Training",
        description: "Meet internal training requirements",
        dueDate: next30Days,
        status: "Compliant",
        percentComplete: 92,
        assignedTo: "Training Coordinator"
      },
      {
        name: "Incident Reporting",
        standard: "Internal",
        category: "Incident Management",
        description: "Maintain incident reporting protocols",
        dueDate: next30Days,
        status: "Compliant",
        percentComplete: 95,
        assignedTo: "Safety Manager"
      },
      {
        name: "Safety Meetings",
        standard: "Internal",
        category: "Communication",
        description: "Conduct regular safety meetings",
        dueDate: next30Days,
        status: "Compliant",
        percentComplete: 90,
        assignedTo: "Department Managers"
      }
    ].forEach(item => {
      this.createComplianceItem({
        name: item.name,
        standard: item.standard,
        category: item.category,
        description: item.description,
        dueDate: item.dueDate,
        completionDate: item.percentComplete === 100 ? now : undefined,
        status: item.status,
        percentComplete: item.percentComplete,
        assignedTo: item.assignedTo,
        evidence: ""
      });
    });
    
    // Example incidents
    [
      {
        incidentId: "INC-2023-125",
        type: "Near Miss",
        description: "Employee slipped but didn't fall on wet floor",
        location: "Production Floor",
        reportedBy: "John Smith",
        reportedDate: new Date("2023-08-01"),
        status: "In Progress",
        severity: "Medium",
        assignedTo: "Safety Manager",
        dueDate: tomorrow
      },
      {
        incidentId: "INC-2023-124",
        type: "Accident",
        description: "Employee strained back while lifting box",
        location: "Warehouse",
        reportedBy: "Jane Doe",
        reportedDate: new Date("2023-07-29"),
        status: "Open",
        severity: "High",
        assignedTo: "Safety Manager",
        dueDate: tomorrow
      },
      {
        incidentId: "INC-2023-123",
        type: "Hazard",
        description: "Chemical spill in lab area",
        location: "Lab Area",
        reportedBy: "Bob Johnson",
        reportedDate: new Date("2023-07-27"),
        status: "Closed",
        severity: "Low",
        assignedTo: "Lab Manager",
        dueDate: now,
        closedDate: now,
        actions: "Area cleaned and procedures reviewed"
      },
      {
        incidentId: "INC-2023-122",
        type: "Near Miss",
        description: "Forklift nearly collided with rack",
        location: "Loading Dock",
        reportedBy: "Mike Wilson",
        reportedDate: new Date("2023-07-25"),
        status: "Closed",
        severity: "Medium",
        assignedTo: "Warehouse Manager",
        dueDate: now,
        closedDate: now,
        actions: "Refresher training provided to operator"
      }
    ].forEach(incident => {
      this.createIncident(incident);
    });
    
    // Example tasks
    [
      {
        title: "Complete incident investigation #124",
        description: "Finalize investigation and recommend corrective actions",
        dueDate: new Date("2023-08-05"),
        assignedTo: "Safety Manager",
        status: "In Progress",
        priority: "High",
        relatedEntityType: "Incident",
        relatedEntityId: 2 // INC-2023-124
      },
      {
        title: "Review safety policy changes",
        description: "Review and approve updated safety policies",
        dueDate: new Date("2023-08-08"),
        assignedTo: "Plant Manager",
        status: "Not Started",
        priority: "Medium",
        relatedEntityType: "Document",
        relatedEntityId: null
      },
      {
        title: "Chemical storage audit preparation",
        description: "Prepare for upcoming chemical storage audit",
        dueDate: new Date("2023-08-12"),
        assignedTo: "Lab Manager",
        status: "Not Started",
        priority: "Medium",
        relatedEntityType: "Audit",
        relatedEntityId: null
      },
      {
        title: "Submit monthly compliance report",
        description: "Complete and submit monthly compliance status report",
        dueDate: new Date("2023-08-30"),
        assignedTo: "Safety Manager",
        status: "Not Started",
        priority: "Low",
        relatedEntityType: "Compliance",
        relatedEntityId: null
      }
    ].forEach(task => {
      this.createTask(task);
    });
    
    // Example audits
    this.createAudit({
      title: "Annual Safety Audit",
      description: "Comprehensive review of all safety programs",
      auditType: "Internal",
      scheduledDate: new Date("2023-08-15"),
      status: "Scheduled",
      auditor: "Safety Team",
      location: "All Facilities",
      findings: ""
    });
    
    this.createAudit({
      title: "ISO 45001 Surveillance Audit",
      description: "Surveillance audit by certification body",
      auditType: "External",
      scheduledDate: new Date("2023-09-10"),
      status: "Scheduled",
      auditor: "ABC Certification",
      location: "Main Facility",
      findings: ""
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserID++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Incident methods
  async getIncidents(): Promise<Incident[]> {
    return Array.from(this.incidents.values());
  }

  async getIncident(id: number): Promise<Incident | undefined> {
    return this.incidents.get(id);
  }

  async createIncident(insertIncident: InsertIncident): Promise<Incident> {
    const id = this.currentIncidentID++;
    const incident: Incident = { ...insertIncident, id };
    this.incidents.set(id, incident);
    return incident;
  }

  async updateIncident(id: number, incidentUpdate: Partial<InsertIncident>): Promise<Incident | undefined> {
    const incident = this.incidents.get(id);
    if (!incident) return undefined;
    
    const updatedIncident = { ...incident, ...incidentUpdate };
    this.incidents.set(id, updatedIncident);
    return updatedIncident;
  }

  async deleteIncident(id: number): Promise<boolean> {
    return this.incidents.delete(id);
  }

  // Document methods
  async getDocuments(): Promise<Document[]> {
    return Array.from(this.documents.values());
  }

  async getDocument(id: number): Promise<Document | undefined> {
    return this.documents.get(id);
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const id = this.currentDocumentID++;
    const document: Document = { ...insertDocument, id };
    this.documents.set(id, document);
    return document;
  }

  async updateDocument(id: number, documentUpdate: Partial<InsertDocument>): Promise<Document | undefined> {
    const document = this.documents.get(id);
    if (!document) return undefined;
    
    const updatedDocument = { ...document, ...documentUpdate };
    this.documents.set(id, updatedDocument);
    return updatedDocument;
  }

  async deleteDocument(id: number): Promise<boolean> {
    return this.documents.delete(id);
  }

  // Compliance Item methods
  async getComplianceItems(): Promise<ComplianceItem[]> {
    return Array.from(this.complianceItems.values());
  }

  async getComplianceItem(id: number): Promise<ComplianceItem | undefined> {
    return this.complianceItems.get(id);
  }

  async createComplianceItem(insertItem: InsertComplianceItem): Promise<ComplianceItem> {
    const id = this.currentComplianceItemID++;
    const item: ComplianceItem = { ...insertItem, id };
    this.complianceItems.set(id, item);
    return item;
  }

  async updateComplianceItem(id: number, itemUpdate: Partial<InsertComplianceItem>): Promise<ComplianceItem | undefined> {
    const item = this.complianceItems.get(id);
    if (!item) return undefined;
    
    const updatedItem = { ...item, ...itemUpdate };
    this.complianceItems.set(id, updatedItem);
    return updatedItem;
  }

  async deleteComplianceItem(id: number): Promise<boolean> {
    return this.complianceItems.delete(id);
  }

  // Audit methods
  async getAudits(): Promise<Audit[]> {
    return Array.from(this.audits.values());
  }

  async getAudit(id: number): Promise<Audit | undefined> {
    return this.audits.get(id);
  }

  async createAudit(insertAudit: InsertAudit): Promise<Audit> {
    const id = this.currentAuditID++;
    const audit: Audit = { ...insertAudit, id };
    this.audits.set(id, audit);
    return audit;
  }

  async updateAudit(id: number, auditUpdate: Partial<InsertAudit>): Promise<Audit | undefined> {
    const audit = this.audits.get(id);
    if (!audit) return undefined;
    
    const updatedAudit = { ...audit, ...auditUpdate };
    this.audits.set(id, updatedAudit);
    return updatedAudit;
  }

  async deleteAudit(id: number): Promise<boolean> {
    return this.audits.delete(id);
  }

  // Risk Assessment methods
  async getRiskAssessments(): Promise<RiskAssessment[]> {
    return Array.from(this.riskAssessments.values());
  }

  async getRiskAssessment(id: number): Promise<RiskAssessment | undefined> {
    return this.riskAssessments.get(id);
  }

  async createRiskAssessment(insertAssessment: InsertRiskAssessment): Promise<RiskAssessment> {
    const id = this.currentRiskAssessmentID++;
    const assessment: RiskAssessment = { ...insertAssessment, id };
    this.riskAssessments.set(id, assessment);
    return assessment;
  }

  async updateRiskAssessment(id: number, assessmentUpdate: Partial<InsertRiskAssessment>): Promise<RiskAssessment | undefined> {
    const assessment = this.riskAssessments.get(id);
    if (!assessment) return undefined;
    
    const updatedAssessment = { ...assessment, ...assessmentUpdate };
    this.riskAssessments.set(id, updatedAssessment);
    return updatedAssessment;
  }

  async deleteRiskAssessment(id: number): Promise<boolean> {
    return this.riskAssessments.delete(id);
  }

  // Task methods
  async getTasks(): Promise<Task[]> {
    return Array.from(this.tasks.values());
  }

  async getTask(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = this.currentTaskID++;
    const task: Task = { ...insertTask, id };
    this.tasks.set(id, task);
    return task;
  }

  async updateTask(id: number, taskUpdate: Partial<InsertTask>): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;
    
    const updatedTask = { ...task, ...taskUpdate };
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }

  async deleteTask(id: number): Promise<boolean> {
    return this.tasks.delete(id);
  }

  // LMS - Course methods
  async getCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }

  async getCourse(id: number): Promise<Course | undefined> {
    return this.courses.get(id);
  }

  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const id = this.currentCourseID++;
    const course: Course = { ...insertCourse, id };
    this.courses.set(id, course);
    return course;
  }

  async updateCourse(id: number, courseUpdate: Partial<InsertCourse>): Promise<Course | undefined> {
    const course = this.courses.get(id);
    if (!course) return undefined;
    
    const updatedCourse = { ...course, ...courseUpdate };
    this.courses.set(id, updatedCourse);
    return updatedCourse;
  }

  async deleteCourse(id: number): Promise<boolean> {
    return this.courses.delete(id);
  }

  // Course Module methods
  async getCourseModules(courseId: number): Promise<CourseModule[]> {
    return Array.from(this.courseModules.values())
      .filter(module => module.courseId === courseId);
  }

  async getCourseModule(id: number): Promise<CourseModule | undefined> {
    return this.courseModules.get(id);
  }

  async createCourseModule(insertModule: InsertCourseModule): Promise<CourseModule> {
    const id = this.currentCourseModuleID++;
    const module: CourseModule = { ...insertModule, id };
    this.courseModules.set(id, module);
    return module;
  }

  async updateCourseModule(id: number, moduleUpdate: Partial<InsertCourseModule>): Promise<CourseModule | undefined> {
    const module = this.courseModules.get(id);
    if (!module) return undefined;
    
    const updatedModule = { ...module, ...moduleUpdate };
    this.courseModules.set(id, updatedModule);
    return updatedModule;
  }

  async deleteCourseModule(id: number): Promise<boolean> {
    return this.courseModules.delete(id);
  }

  // Course Enrollment methods
  async getEnrollments(userId?: number, courseId?: number): Promise<CourseEnrollment[]> {
    const enrollments = Array.from(this.courseEnrollments.values());
    
    if (userId && courseId) {
      return enrollments.filter(
        enrollment => enrollment.userId === userId && enrollment.courseId === courseId
      );
    } else if (userId) {
      return enrollments.filter(enrollment => enrollment.userId === userId);
    } else if (courseId) {
      return enrollments.filter(enrollment => enrollment.courseId === courseId);
    }
    
    return enrollments;
  }

  async getEnrollment(id: number): Promise<CourseEnrollment | undefined> {
    return this.courseEnrollments.get(id);
  }

  async createEnrollment(insertEnrollment: InsertEnrollment): Promise<CourseEnrollment> {
    const id = this.currentEnrollmentID++;
    const enrollment: CourseEnrollment = { ...insertEnrollment, id };
    this.courseEnrollments.set(id, enrollment);
    return enrollment;
  }

  async updateEnrollment(id: number, enrollmentUpdate: Partial<InsertEnrollment>): Promise<CourseEnrollment | undefined> {
    const enrollment = this.courseEnrollments.get(id);
    if (!enrollment) return undefined;
    
    const updatedEnrollment = { ...enrollment, ...enrollmentUpdate };
    this.courseEnrollments.set(id, updatedEnrollment);
    return updatedEnrollment;
  }

  async deleteEnrollment(id: number): Promise<boolean> {
    return this.courseEnrollments.delete(id);
  }

  // Calendar Event methods
  async getCalendarEvents(startDate?: Date, endDate?: Date): Promise<CalendarEvent[]> {
    const events = Array.from(this.calendarEvents.values());
    
    if (startDate && endDate) {
      return events.filter(
        event => event.startTime >= startDate && event.startTime <= endDate
      );
    } else if (startDate) {
      return events.filter(event => event.startTime >= startDate);
    } else if (endDate) {
      return events.filter(event => event.startTime <= endDate);
    }
    
    return events;
  }

  async getCalendarEvent(id: number): Promise<CalendarEvent | undefined> {
    return this.calendarEvents.get(id);
  }

  async createCalendarEvent(insertEvent: InsertCalendarEvent): Promise<CalendarEvent> {
    const id = this.currentEventID++;
    const event: CalendarEvent = { ...insertEvent, id };
    this.calendarEvents.set(id, event);
    return event;
  }

  async updateCalendarEvent(id: number, eventUpdate: Partial<InsertCalendarEvent>): Promise<CalendarEvent | undefined> {
    const event = this.calendarEvents.get(id);
    if (!event) return undefined;
    
    const updatedEvent = { ...event, ...eventUpdate };
    this.calendarEvents.set(id, updatedEvent);
    return updatedEvent;
  }

  async deleteCalendarEvent(id: number): Promise<boolean> {
    return this.calendarEvents.delete(id);
  }

  // Event Attendee methods
  async getEventAttendees(eventId: number): Promise<EventAttendee[]> {
    return Array.from(this.eventAttendees.values())
      .filter(attendee => attendee.eventId === eventId);
  }

  async getEventAttendee(id: number): Promise<EventAttendee | undefined> {
    return this.eventAttendees.get(id);
  }

  async createEventAttendee(insertAttendee: InsertEventAttendee): Promise<EventAttendee> {
    const id = this.currentAttendeeID++;
    const attendee: EventAttendee = { ...insertAttendee, id };
    this.eventAttendees.set(id, attendee);
    return attendee;
  }

  async updateEventAttendee(id: number, attendeeUpdate: Partial<InsertEventAttendee>): Promise<EventAttendee | undefined> {
    const attendee = this.eventAttendees.get(id);
    if (!attendee) return undefined;
    
    const updatedAttendee = { ...attendee, ...attendeeUpdate };
    this.eventAttendees.set(id, updatedAttendee);
    return updatedAttendee;
  }

  async deleteEventAttendee(id: number): Promise<boolean> {
    return this.eventAttendees.delete(id);
  }
}

export const storage = new MemStorage();
