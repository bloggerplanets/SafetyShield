import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertIncidentSchema, 
  insertDocumentSchema, 
  insertComplianceItemSchema, 
  insertAuditSchema, 
  insertRiskAssessmentSchema, 
  insertTaskSchema,
  insertUserSchema,
  insertCourseSchema,
  insertCourseModuleSchema,
  insertEnrollmentSchema,
  insertCalendarEventSchema,
  insertEventAttendeeSchema
} from "@shared/schema";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  const apiRouter = express.Router();
  
  // *****************************
  // Incidents routes
  // *****************************
  
  apiRouter.get("/incidents", async (_req: Request, res: Response) => {
    try {
      const incidents = await storage.getIncidents();
      res.json(incidents);
    } catch (error) {
      console.error("Error fetching incidents:", error);
      res.status(500).json({ message: "Failed to fetch incidents" });
    }
  });
  
  apiRouter.get("/incidents/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const incident = await storage.getIncident(id);
      if (!incident) {
        return res.status(404).json({ message: "Incident not found" });
      }
      
      res.json(incident);
    } catch (error) {
      console.error("Error fetching incident:", error);
      res.status(500).json({ message: "Failed to fetch incident" });
    }
  });

  apiRouter.post("/incidents", async (req: Request, res: Response) => {
    try {
      // Make sure dates are properly parsed
      const formData = { ...req.body };
      
      // Convert reportedDate from ISO string to Date if it's a string
      if (typeof formData.reportedDate === 'string') {
        formData.reportedDate = new Date(formData.reportedDate);
        console.log("Converted reportedDate to Date:", formData.reportedDate);
      }
      
      // Convert optional dates if they exist
      if (typeof formData.dueDate === 'string') {
        formData.dueDate = new Date(formData.dueDate);
      }
      
      if (typeof formData.closedDate === 'string') {
        formData.closedDate = new Date(formData.closedDate);
      }
      
      const result = insertIncidentSchema.safeParse(formData);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        console.error("Validation error:", errorMessage, "Data:", formData);
        return res.status(400).json({ message: errorMessage });
      }
      
      const newIncident = await storage.createIncident(result.data);
      res.status(201).json(newIncident);
    } catch (error) {
      console.error("Error creating incident:", error);
      res.status(500).json({ message: "Failed to create incident" });
    }
  });

  apiRouter.put("/incidents/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      // Make sure dates are properly parsed
      const formData = { ...req.body };
      
      // Convert reportedDate from ISO string to Date if it's a string
      if (typeof formData.reportedDate === 'string') {
        formData.reportedDate = new Date(formData.reportedDate);
      }
      
      // Convert optional dates if they exist
      if (typeof formData.dueDate === 'string') {
        formData.dueDate = new Date(formData.dueDate);
      }
      
      if (typeof formData.closedDate === 'string') {
        formData.closedDate = new Date(formData.closedDate);
      }
      
      // Validate only the fields that are provided
      const result = insertIncidentSchema.partial().safeParse(formData);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        console.error("Validation error:", errorMessage, "Data:", formData);
        return res.status(400).json({ message: errorMessage });
      }
      
      const updatedIncident = await storage.updateIncident(id, result.data);
      if (!updatedIncident) {
        return res.status(404).json({ message: "Incident not found" });
      }
      
      res.json(updatedIncident);
    } catch (error) {
      console.error("Error updating incident:", error);
      res.status(500).json({ message: "Failed to update incident" });
    }
  });

  apiRouter.delete("/incidents/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const success = await storage.deleteIncident(id);
      if (!success) {
        return res.status(404).json({ message: "Incident not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting incident:", error);
      res.status(500).json({ message: "Failed to delete incident" });
    }
  });
  
  // *****************************
  // Documents routes
  // *****************************
  
  apiRouter.get("/documents", async (_req: Request, res: Response) => {
    try {
      const documents = await storage.getDocuments();
      res.json(documents);
    } catch (error) {
      console.error("Error fetching documents:", error);
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });
  
  apiRouter.get("/documents/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const document = await storage.getDocument(id);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      
      res.json(document);
    } catch (error) {
      console.error("Error fetching document:", error);
      res.status(500).json({ message: "Failed to fetch document" });
    }
  });

  apiRouter.post("/documents", async (req: Request, res: Response) => {
    try {
      // Parse dates properly
      const formData = { ...req.body };
      
      // Convert date strings to Date objects
      if (typeof formData.uploadDate === 'string') {
        formData.uploadDate = new Date(formData.uploadDate);
      }
      
      if (typeof formData.expiryDate === 'string') {
        formData.expiryDate = new Date(formData.expiryDate);
      }
      
      const result = insertDocumentSchema.safeParse(formData);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        console.error("Validation error:", errorMessage, "Data:", formData);
        return res.status(400).json({ message: errorMessage });
      }
      
      const newDocument = await storage.createDocument(result.data);
      res.status(201).json(newDocument);
    } catch (error) {
      console.error("Error creating document:", error);
      res.status(500).json({ message: "Failed to create document" });
    }
  });

  apiRouter.put("/documents/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      // Parse dates properly
      const formData = { ...req.body };
      
      // Convert date strings to Date objects
      if (typeof formData.uploadDate === 'string') {
        formData.uploadDate = new Date(formData.uploadDate);
      }
      
      if (typeof formData.expiryDate === 'string') {
        formData.expiryDate = new Date(formData.expiryDate);
      }
      
      const result = insertDocumentSchema.partial().safeParse(formData);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        console.error("Validation error:", errorMessage, "Data:", formData);
        return res.status(400).json({ message: errorMessage });
      }
      
      const updatedDocument = await storage.updateDocument(id, result.data);
      if (!updatedDocument) {
        return res.status(404).json({ message: "Document not found" });
      }
      
      res.json(updatedDocument);
    } catch (error) {
      console.error("Error updating document:", error);
      res.status(500).json({ message: "Failed to update document" });
    }
  });

  apiRouter.delete("/documents/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const success = await storage.deleteDocument(id);
      if (!success) {
        return res.status(404).json({ message: "Document not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting document:", error);
      res.status(500).json({ message: "Failed to delete document" });
    }
  });
  
  // *****************************
  // Compliance Items routes
  // *****************************
  
  apiRouter.get("/compliance", async (_req: Request, res: Response) => {
    try {
      const items = await storage.getComplianceItems();
      res.json(items);
    } catch (error) {
      console.error("Error fetching compliance items:", error);
      res.status(500).json({ message: "Failed to fetch compliance items" });
    }
  });
  
  apiRouter.get("/compliance/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const item = await storage.getComplianceItem(id);
      if (!item) {
        return res.status(404).json({ message: "Compliance item not found" });
      }
      
      res.json(item);
    } catch (error) {
      console.error("Error fetching compliance item:", error);
      res.status(500).json({ message: "Failed to fetch compliance item" });
    }
  });

  apiRouter.post("/compliance", async (req: Request, res: Response) => {
    try {
      const result = insertComplianceItemSchema.safeParse(req.body);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      const newItem = await storage.createComplianceItem(result.data);
      res.status(201).json(newItem);
    } catch (error) {
      console.error("Error creating compliance item:", error);
      res.status(500).json({ message: "Failed to create compliance item" });
    }
  });

  apiRouter.put("/compliance/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const result = insertComplianceItemSchema.partial().safeParse(req.body);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      const updatedItem = await storage.updateComplianceItem(id, result.data);
      if (!updatedItem) {
        return res.status(404).json({ message: "Compliance item not found" });
      }
      
      res.json(updatedItem);
    } catch (error) {
      console.error("Error updating compliance item:", error);
      res.status(500).json({ message: "Failed to update compliance item" });
    }
  });

  apiRouter.delete("/compliance/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const success = await storage.deleteComplianceItem(id);
      if (!success) {
        return res.status(404).json({ message: "Compliance item not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting compliance item:", error);
      res.status(500).json({ message: "Failed to delete compliance item" });
    }
  });
  
  // *****************************
  // Audits routes
  // *****************************
  
  apiRouter.get("/audits", async (_req: Request, res: Response) => {
    try {
      const audits = await storage.getAudits();
      res.json(audits);
    } catch (error) {
      console.error("Error fetching audits:", error);
      res.status(500).json({ message: "Failed to fetch audits" });
    }
  });
  
  apiRouter.get("/audits/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const audit = await storage.getAudit(id);
      if (!audit) {
        return res.status(404).json({ message: "Audit not found" });
      }
      
      res.json(audit);
    } catch (error) {
      console.error("Error fetching audit:", error);
      res.status(500).json({ message: "Failed to fetch audit" });
    }
  });

  apiRouter.post("/audits", async (req: Request, res: Response) => {
    try {
      const result = insertAuditSchema.safeParse(req.body);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      const newAudit = await storage.createAudit(result.data);
      res.status(201).json(newAudit);
    } catch (error) {
      console.error("Error creating audit:", error);
      res.status(500).json({ message: "Failed to create audit" });
    }
  });

  apiRouter.put("/audits/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const result = insertAuditSchema.partial().safeParse(req.body);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      const updatedAudit = await storage.updateAudit(id, result.data);
      if (!updatedAudit) {
        return res.status(404).json({ message: "Audit not found" });
      }
      
      res.json(updatedAudit);
    } catch (error) {
      console.error("Error updating audit:", error);
      res.status(500).json({ message: "Failed to update audit" });
    }
  });

  apiRouter.delete("/audits/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const success = await storage.deleteAudit(id);
      if (!success) {
        return res.status(404).json({ message: "Audit not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting audit:", error);
      res.status(500).json({ message: "Failed to delete audit" });
    }
  });
  
  // *****************************
  // Risk Assessments routes
  // *****************************
  
  apiRouter.get("/risk-assessments", async (_req: Request, res: Response) => {
    try {
      const assessments = await storage.getRiskAssessments();
      res.json(assessments);
    } catch (error) {
      console.error("Error fetching risk assessments:", error);
      res.status(500).json({ message: "Failed to fetch risk assessments" });
    }
  });
  
  apiRouter.get("/risk-assessments/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const assessment = await storage.getRiskAssessment(id);
      if (!assessment) {
        return res.status(404).json({ message: "Risk assessment not found" });
      }
      
      res.json(assessment);
    } catch (error) {
      console.error("Error fetching risk assessment:", error);
      res.status(500).json({ message: "Failed to fetch risk assessment" });
    }
  });

  apiRouter.post("/risk-assessments", async (req: Request, res: Response) => {
    try {
      const result = insertRiskAssessmentSchema.safeParse(req.body);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      const newAssessment = await storage.createRiskAssessment(result.data);
      res.status(201).json(newAssessment);
    } catch (error) {
      console.error("Error creating risk assessment:", error);
      res.status(500).json({ message: "Failed to create risk assessment" });
    }
  });

  apiRouter.put("/risk-assessments/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const result = insertRiskAssessmentSchema.partial().safeParse(req.body);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      const updatedAssessment = await storage.updateRiskAssessment(id, result.data);
      if (!updatedAssessment) {
        return res.status(404).json({ message: "Risk assessment not found" });
      }
      
      res.json(updatedAssessment);
    } catch (error) {
      console.error("Error updating risk assessment:", error);
      res.status(500).json({ message: "Failed to update risk assessment" });
    }
  });

  apiRouter.delete("/risk-assessments/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const success = await storage.deleteRiskAssessment(id);
      if (!success) {
        return res.status(404).json({ message: "Risk assessment not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting risk assessment:", error);
      res.status(500).json({ message: "Failed to delete risk assessment" });
    }
  });
  
  // *****************************
  // Tasks routes
  // *****************************
  
  apiRouter.get("/tasks", async (_req: Request, res: Response) => {
    try {
      const tasks = await storage.getTasks();
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });
  
  apiRouter.get("/tasks/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const task = await storage.getTask(id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      res.json(task);
    } catch (error) {
      console.error("Error fetching task:", error);
      res.status(500).json({ message: "Failed to fetch task" });
    }
  });

  apiRouter.post("/tasks", async (req: Request, res: Response) => {
    try {
      const result = insertTaskSchema.safeParse(req.body);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      const newTask = await storage.createTask(result.data);
      res.status(201).json(newTask);
    } catch (error) {
      console.error("Error creating task:", error);
      res.status(500).json({ message: "Failed to create task" });
    }
  });

  apiRouter.put("/tasks/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const result = insertTaskSchema.partial().safeParse(req.body);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      const updatedTask = await storage.updateTask(id, result.data);
      if (!updatedTask) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      res.json(updatedTask);
    } catch (error) {
      console.error("Error updating task:", error);
      res.status(500).json({ message: "Failed to update task" });
    }
  });

  apiRouter.delete("/tasks/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const success = await storage.deleteTask(id);
      if (!success) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting task:", error);
      res.status(500).json({ message: "Failed to delete task" });
    }
  });

  // Register API routes with prefix
  // *****************************
  // Authentication routes
  // *****************************
  
  apiRouter.post("/auth/register", async (req: Request, res: Response) => {
    try {
      const result = insertUserSchema.safeParse(req.body);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(result.data.username);
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      
      // In a real app, we would hash the password here
      const newUser = await storage.createUser(result.data);
      
      // Don't return the password in the response
      const { password, ...userWithoutPassword } = newUser;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Failed to create user" });
    }
  });
  
  apiRouter.post("/auth/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      // In a real app, we would verify the hashed password here
      if (user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      // Don't return the password in the response
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error during login:", error);
      res.status(500).json({ message: "Login failed due to an internal error" });
    }
  });
  
  apiRouter.post("/auth/forgot-password", async (req: Request, res: Response) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }
      
      // In a real app, we would:
      // 1. Find user by email
      // 2. Generate a reset token
      // 3. Set an expiry time
      // 4. Send an email with a reset link
      
      // For now, just return a success message
      res.json({ 
        message: "If an account with that email exists, a password reset link has been sent" 
      });
    } catch (error) {
      console.error("Error during password reset request:", error);
      res.status(500).json({ message: "Request failed due to an internal error" });
    }
  });
  
  apiRouter.post("/auth/reset-password", async (req: Request, res: Response) => {
    try {
      const { token, newPassword } = req.body;
      
      if (!token || !newPassword) {
        return res.status(400).json({ 
          message: "Reset token and new password are required" 
        });
      }
      
      // In a real app, we would:
      // 1. Verify the token is valid and not expired
      // 2. Find the user associated with the token
      // 3. Hash the new password
      // 4. Update the user's password
      // 5. Clear the reset token and expiry
      
      // For now, just return a success message
      res.json({ message: "Password has been reset successfully" });
    } catch (error) {
      console.error("Error during password reset:", error);
      res.status(500).json({ message: "Password reset failed due to an internal error" });
    }
  });
  
  // *****************************
  // LMS routes
  // *****************************
  
  // Courses
  apiRouter.get("/courses", async (_req: Request, res: Response) => {
    try {
      const courses = await storage.getCourses();
      res.json(courses);
    } catch (error) {
      console.error("Error fetching courses:", error);
      res.status(500).json({ message: "Failed to fetch courses" });
    }
  });
  
  apiRouter.get("/courses/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const course = await storage.getCourse(id);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      res.json(course);
    } catch (error) {
      console.error("Error fetching course:", error);
      res.status(500).json({ message: "Failed to fetch course" });
    }
  });
  
  apiRouter.post("/courses", async (req: Request, res: Response) => {
    try {
      // Parse dates properly
      const formData = { ...req.body };
      
      const result = insertCourseSchema.safeParse(formData);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        console.error("Validation error:", errorMessage, "Data:", formData);
        return res.status(400).json({ message: errorMessage });
      }
      
      const newCourse = await storage.createCourse(result.data);
      res.status(201).json(newCourse);
    } catch (error) {
      console.error("Error creating course:", error);
      res.status(500).json({ message: "Failed to create course" });
    }
  });
  
  apiRouter.put("/courses/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const formData = { ...req.body };
      
      const result = insertCourseSchema.partial().safeParse(formData);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        console.error("Validation error:", errorMessage, "Data:", formData);
        return res.status(400).json({ message: errorMessage });
      }
      
      const updatedCourse = await storage.updateCourse(id, result.data);
      if (!updatedCourse) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      res.json(updatedCourse);
    } catch (error) {
      console.error("Error updating course:", error);
      res.status(500).json({ message: "Failed to update course" });
    }
  });
  
  apiRouter.delete("/courses/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const success = await storage.deleteCourse(id);
      if (!success) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting course:", error);
      res.status(500).json({ message: "Failed to delete course" });
    }
  });
  
  // Course Modules
  apiRouter.get("/courses/:courseId/modules", async (req: Request, res: Response) => {
    try {
      const courseId = parseInt(req.params.courseId);
      if (isNaN(courseId)) {
        return res.status(400).json({ message: "Invalid course ID format" });
      }
      
      const modules = await storage.getCourseModules(courseId);
      res.json(modules);
    } catch (error) {
      console.error("Error fetching course modules:", error);
      res.status(500).json({ message: "Failed to fetch course modules" });
    }
  });
  
  apiRouter.get("/modules/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const module = await storage.getCourseModule(id);
      if (!module) {
        return res.status(404).json({ message: "Module not found" });
      }
      
      res.json(module);
    } catch (error) {
      console.error("Error fetching module:", error);
      res.status(500).json({ message: "Failed to fetch module" });
    }
  });
  
  apiRouter.post("/modules", async (req: Request, res: Response) => {
    try {
      const result = insertCourseModuleSchema.safeParse(req.body);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      const newModule = await storage.createCourseModule(result.data);
      res.status(201).json(newModule);
    } catch (error) {
      console.error("Error creating module:", error);
      res.status(500).json({ message: "Failed to create module" });
    }
  });
  
  apiRouter.put("/modules/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const result = insertCourseModuleSchema.partial().safeParse(req.body);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      const updatedModule = await storage.updateCourseModule(id, result.data);
      if (!updatedModule) {
        return res.status(404).json({ message: "Module not found" });
      }
      
      res.json(updatedModule);
    } catch (error) {
      console.error("Error updating module:", error);
      res.status(500).json({ message: "Failed to update module" });
    }
  });
  
  apiRouter.delete("/modules/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const success = await storage.deleteCourseModule(id);
      if (!success) {
        return res.status(404).json({ message: "Module not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting module:", error);
      res.status(500).json({ message: "Failed to delete module" });
    }
  });
  
  // Course Enrollments
  apiRouter.get("/enrollments", async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      const courseId = req.query.courseId ? parseInt(req.query.courseId as string) : undefined;
      
      const enrollments = await storage.getEnrollments(userId, courseId);
      res.json(enrollments);
    } catch (error) {
      console.error("Error fetching enrollments:", error);
      res.status(500).json({ message: "Failed to fetch enrollments" });
    }
  });
  
  apiRouter.get("/enrollments/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const enrollment = await storage.getEnrollment(id);
      if (!enrollment) {
        return res.status(404).json({ message: "Enrollment not found" });
      }
      
      res.json(enrollment);
    } catch (error) {
      console.error("Error fetching enrollment:", error);
      res.status(500).json({ message: "Failed to fetch enrollment" });
    }
  });
  
  apiRouter.post("/enrollments", async (req: Request, res: Response) => {
    try {
      // Handle date conversions
      const formData = { ...req.body };
      
      if (typeof formData.completedAt === 'string') {
        formData.completedAt = new Date(formData.completedAt);
      }
      
      if (typeof formData.expiresAt === 'string') {
        formData.expiresAt = new Date(formData.expiresAt);
      }
      
      const result = insertEnrollmentSchema.safeParse(formData);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      const newEnrollment = await storage.createEnrollment(result.data);
      res.status(201).json(newEnrollment);
    } catch (error) {
      console.error("Error creating enrollment:", error);
      res.status(500).json({ message: "Failed to create enrollment" });
    }
  });
  
  apiRouter.put("/enrollments/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      // Handle date conversions
      const formData = { ...req.body };
      
      if (typeof formData.completedAt === 'string') {
        formData.completedAt = new Date(formData.completedAt);
      }
      
      if (typeof formData.expiresAt === 'string') {
        formData.expiresAt = new Date(formData.expiresAt);
      }
      
      const result = insertEnrollmentSchema.partial().safeParse(formData);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      const updatedEnrollment = await storage.updateEnrollment(id, result.data);
      if (!updatedEnrollment) {
        return res.status(404).json({ message: "Enrollment not found" });
      }
      
      res.json(updatedEnrollment);
    } catch (error) {
      console.error("Error updating enrollment:", error);
      res.status(500).json({ message: "Failed to update enrollment" });
    }
  });
  
  apiRouter.delete("/enrollments/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const success = await storage.deleteEnrollment(id);
      if (!success) {
        return res.status(404).json({ message: "Enrollment not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting enrollment:", error);
      res.status(500).json({ message: "Failed to delete enrollment" });
    }
  });
  
  // *****************************
  // Calendar routes
  // *****************************
  
  // Events
  apiRouter.get("/calendar/events", async (req: Request, res: Response) => {
    try {
      const startDate = req.query.start ? new Date(req.query.start as string) : undefined;
      const endDate = req.query.end ? new Date(req.query.end as string) : undefined;
      
      const events = await storage.getCalendarEvents(startDate, endDate);
      res.json(events);
    } catch (error) {
      console.error("Error fetching calendar events:", error);
      res.status(500).json({ message: "Failed to fetch calendar events" });
    }
  });
  
  apiRouter.get("/calendar/events/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const event = await storage.getCalendarEvent(id);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      res.json(event);
    } catch (error) {
      console.error("Error fetching calendar event:", error);
      res.status(500).json({ message: "Failed to fetch calendar event" });
    }
  });
  
  apiRouter.post("/calendar/events", async (req: Request, res: Response) => {
    try {
      // Handle date conversions
      const formData = { ...req.body };
      
      if (typeof formData.startTime === 'string') {
        formData.startTime = new Date(formData.startTime);
      }
      
      if (typeof formData.endTime === 'string') {
        formData.endTime = new Date(formData.endTime);
      }
      
      const result = insertCalendarEventSchema.safeParse(formData);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      const newEvent = await storage.createCalendarEvent(result.data);
      res.status(201).json(newEvent);
    } catch (error) {
      console.error("Error creating calendar event:", error);
      res.status(500).json({ message: "Failed to create calendar event" });
    }
  });
  
  apiRouter.put("/calendar/events/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      // Handle date conversions
      const formData = { ...req.body };
      
      if (typeof formData.startTime === 'string') {
        formData.startTime = new Date(formData.startTime);
      }
      
      if (typeof formData.endTime === 'string') {
        formData.endTime = new Date(formData.endTime);
      }
      
      const result = insertCalendarEventSchema.partial().safeParse(formData);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      const updatedEvent = await storage.updateCalendarEvent(id, result.data);
      if (!updatedEvent) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      res.json(updatedEvent);
    } catch (error) {
      console.error("Error updating calendar event:", error);
      res.status(500).json({ message: "Failed to update calendar event" });
    }
  });
  
  apiRouter.delete("/calendar/events/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const success = await storage.deleteCalendarEvent(id);
      if (!success) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting calendar event:", error);
      res.status(500).json({ message: "Failed to delete calendar event" });
    }
  });
  
  // Event Attendees
  apiRouter.get("/calendar/events/:eventId/attendees", async (req: Request, res: Response) => {
    try {
      const eventId = parseInt(req.params.eventId);
      if (isNaN(eventId)) {
        return res.status(400).json({ message: "Invalid event ID format" });
      }
      
      const attendees = await storage.getEventAttendees(eventId);
      res.json(attendees);
    } catch (error) {
      console.error("Error fetching event attendees:", error);
      res.status(500).json({ message: "Failed to fetch event attendees" });
    }
  });
  
  apiRouter.post("/calendar/attendees", async (req: Request, res: Response) => {
    try {
      const result = insertEventAttendeeSchema.safeParse(req.body);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      const newAttendee = await storage.createEventAttendee(result.data);
      res.status(201).json(newAttendee);
    } catch (error) {
      console.error("Error creating event attendee:", error);
      res.status(500).json({ message: "Failed to create event attendee" });
    }
  });
  
  apiRouter.put("/calendar/attendees/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const result = insertEventAttendeeSchema.partial().safeParse(req.body);
      
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      const updatedAttendee = await storage.updateEventAttendee(id, result.data);
      if (!updatedAttendee) {
        return res.status(404).json({ message: "Attendee not found" });
      }
      
      res.json(updatedAttendee);
    } catch (error) {
      console.error("Error updating event attendee:", error);
      res.status(500).json({ message: "Failed to update event attendee" });
    }
  });
  
  apiRouter.delete("/calendar/attendees/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const success = await storage.deleteEventAttendee(id);
      if (!success) {
        return res.status(404).json({ message: "Attendee not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting event attendee:", error);
      res.status(500).json({ message: "Failed to delete event attendee" });
    }
  });

  app.use("/api", apiRouter);

  const httpServer = createServer(app);
  return httpServer;
}
